import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Activity,
  AlertCircle,
  ChevronDown,
  Clock,
  Loader2,
  Filter,
  Search,
  DollarSign,
  Target,
  Gauge,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  X,
  Power,
} from 'lucide-react';
import { useStrategies } from '../hooks/useStrategies';
import { marketService } from '../lib/market-service';
import { BudgetControl } from './BudgetControl';
import { tradeGenerator } from '../lib/trade-generator';
import { marketMonitor } from '../lib/market-monitor';
import { logService } from '../lib/log-service';
import { BudgetModal } from './BudgetModal';
import { tradeService } from '../lib/trade-service';
import { AssetPairMonitor } from './AssetPairMonitor';
import { tradeManager } from '../lib/trade-manager';
import { EmergencyStopButton } from './EmergencyStopButton';
import type { Strategy } from '../lib/supabase-types';
import type { StrategyBudget } from '../lib/types';

const TradeMonitor = () => {
  const {
    strategies,
    loading: strategiesLoading,
    updateStrategy,
    refresh,
  } = useStrategies();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'profit' | 'loss'>(
    'all'
  );
  const [expandedStrategies, setExpandedStrategies] = useState<Set<string>>(
    new Set()
  );
  const [marketData, setMarketData] = useState<Map<string, any>>(new Map());
  const [showBudgetModal, setShowBudgetModal] = useState(false);
  const [pendingStrategy, setPendingStrategy] = useState<Strategy | null>(null);
  const [isSubmittingBudget, setIsSubmittingBudget] = useState(false);
  const [monitoringInitialized, setMonitoringInitialized] = useState(false);
  const [deactivatingStrategy, setDeactivatingStrategy] = useState<
    string | null
  >(null);

  useEffect(() => {
    if (!strategiesLoading && !monitoringInitialized) {
      initializeMonitoring();
    }
  }, [strategiesLoading, monitoringInitialized]);

  const initializeMonitoring = async () => {
    try {
      setLoading(true);
      setError(null);
      await marketService.initialize();
      const activeStrategies = strategies.filter((s) => s.status === 'active');
      for (const strategy of activeStrategies) {
        await startStrategyMonitoring(strategy);
      }
      setMonitoringInitialized(true);
      setLoading(false);
    } catch (error) {
      setError('Failed to initialize monitoring');
      logService.log(
        'error',
        'Error initializing monitoring:',
        error,
        'TradeMonitor'
      );
      setLoading(false);
    }
  };

  const startStrategyMonitoring = async (strategy: Strategy) => {
    try {
      logService.log(
        'info',
        `Starting monitoring for strategy ${strategy.id}`,
        strategy,
        'TradeMonitor'
      );
      if (strategy.strategy_config?.assets) {
        for (const asset of strategy.strategy_config.assets) {
          await marketMonitor.addAsset(asset);
        }
      }
      await tradeGenerator.addStrategy(strategy);
      await marketService.startStrategyMonitoring(strategy);
      logService.log(
        'info',
        `Successfully started monitoring for strategy ${strategy.id}`,
        null,
        'TradeMonitor'
      );
    } catch (error) {
      logService.log(
        'error',
        `Failed to start monitoring for strategy ${strategy.id}`,
        error,
        'TradeMonitor'
      );
      throw error;
    }
  };

  const handleBudgetConfirm = async (budget: StrategyBudget) => {
    if (!pendingStrategy) return;

    try {
      setError(null);
      setIsSubmittingBudget(true);
      const strategy = pendingStrategy;
      // First set the budget
      await tradeService.setBudget(strategy.id, budget);
      // Then start the strategy monitoring
      await marketService.startStrategyMonitoring(strategy);
      // Finally update the strategy status
      await updateStrategy(strategy.id, {
        status: 'active',
        updated_at: new Date().toISOString(),
      });
      // Clear modal state
      setShowBudgetModal(false);
      setPendingStrategy(null);
      setSelectedStrategy(null);
      // Refresh strategies list
      refresh();
      logService.log(
        'info',
        `Strategy ${strategy.id} activated with budget`,
        { budget },
        'TradeMonitor'
      );
    } catch (error) {
      logService.log(
        'error',
        'Failed to start strategy with budget',
        error,
        'TradeMonitor'
      );
      setError('Failed to activate strategy. Please try again.');
      // Clean up on failure
      if (pendingStrategy) {
        await tradeService.setBudget(pendingStrategy.id, null);
      }
    } finally {
      setIsSubmittingBudget(false);
    }
  };

  const handleStrategyDeactivate = async (strategyId: string) => {
    try {
      setDeactivatingStrategy(strategyId);
      const strategy = strategies.find((s) => s.id === strategyId);
      if (!strategy) throw new Error('Strategy not found');

      // Confirm deactivation
      if (
        !window.confirm(
          `Are you sure you want to deactivate ${strategy.title}? This will close all active trades.`
        )
      ) {
        return;
      }

      // Close all active trades
      const trades = tradeManager.getActiveTradesForStrategy(strategyId);
      for (const trade of trades) {
        await tradeManager.closeTrade(trade.id);
      }

      // Stop strategy monitoring
      await marketService.stopStrategyMonitoring(strategyId);

      // Clear budget
      await tradeService.setBudget(strategyId, null);

      // Update strategy status
      await updateStrategy(strategyId, {
        status: 'inactive',
        updated_at: new Date().toISOString(),
      });

      // Refresh strategies list
      refresh();

      logService.log(
        'info',
        `Strategy ${strategyId} deactivated successfully`,
        null,
        'TradeMonitor'
      );
    } catch (error) {
      logService.log(
        'error',
        `Failed to deactivate strategy ${strategyId}`,
        error,
        'TradeMonitor'
      );
      setError('Failed to deactivate strategy. Please try again.');
    } finally {
      setDeactivatingStrategy(null);
    }
  };

  const handleStrategyActivate = async (strategy: Strategy) => {
    try {
      // Consolidate activation state by using pendingStrategy only.
      setPendingStrategy(strategy);
      setSelectedStrategy(strategy.id);
      setShowBudgetModal(true);
    } catch (error) {
      logService.log(
        'error',
        `Failed to activate strategy ${strategy.id}`,
        error,
        'TradeMonitor'
      );
      setError('Failed to activate strategy. Please try again.');
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      if (!monitoringInitialized) {
        await initializeMonitoring();
      }
      await refresh();
    } finally {
      setRefreshing(false);
    }
  };

  const handleTradeSignal = async (strategy: Strategy, signal: any) => {
    try {
      logService.log(
        'info',
        `Trade signal received for strategy ${strategy.id}`,
        signal,
        'TradeMonitor'
      );
      await tradeManager.executeTrade(strategy, signal.config);
    } catch (error) {
      logService.log(
        'error',
        `Failed to execute trade for strategy ${strategy.id}`,
        error,
        'TradeMonitor'
      );
    }
  };

  const filteredStrategies = React.useMemo(
    () =>
      strategies.filter((s) => {
        const matchesSearch =
          s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.description?.toLowerCase().includes(searchTerm.toLowerCase());
        if (statusFilter === 'profit' && s.pnl <= 0) return false;
        if (statusFilter === 'loss' && s.pnl >= 0) return false;
        return matchesSearch;
      }),
    [strategies, searchTerm, statusFilter]
  );

  return (
    <div className="p-8 space-y-6">
      <div className="bg-gunmetal-800/20 rounded-xl p-4 mb-6">
        <h2 className="text-lg font-semibold text-gray-200 mb-2">
          Trade Monitor
        </h2>
        <p className="text-sm text-gray-400">
          Monitor your active trades in real-time. Track positions, P&L, and
          market conditions. Close trades manually or let your strategy manage
          them automatically.
        </p>
      </div>

      {/* Emergency Stop Button */}
      <div className="bg-gunmetal-800/20 rounded-xl p-4 mb-6">
        <EmergencyStopButton />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Dashboard Cards */}
        <div className="bg-gunmetal-800/20 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-neon-raspberry" />
              <p className="text-sm text-gray-400">Active Strategies</p>
            </div>
            <Target className="w-5 h-5 text-gray-500" />
          </div>
          <p className="text-2xl font-bold text-neon-turquoise">
            {strategies.filter((s) => s.status === 'active').length}
          </p>
        </div>

        <div className="bg-gunmetal-800/20 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Gauge className="w-5 h-5 text-neon-yellow" />
              <p className="text-sm text-gray-400">Total P&L</p>
            </div>
            <Target className="w-5 h-5 text-gray-500" />
          </div>
          <p className="text-2xl font-bold text-neon-yellow">+2.5%</p>
        </div>

        <div className="bg-gunmetal-800/20 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-neon-orange" />
              <p className="text-sm text-gray-400">Win Rate</p>
            </div>
            <TrendingUp className="w-5 h-5 text-gray-500" />
          </div>
          <p className="text-2xl font-bold text-neon-orange">68.5%</p>
        </div>

        <div className="bg-gunmetal-800/20 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-neon-turquoise" />
              <p className="text-sm text-gray-400">Avg Duration</p>
            </div>
            <Gauge className="w-5 h-5 text-gray-500" />
          </div>
          <p className="text-2xl font-bold text-neon-turquoise">4.2h</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search strategies..."
              className="w-full bg-gunmetal-800 border border-gunmetal-700 rounded-lg pl-10 pr-4 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-raspberry focus:border-transparent"
            />
          </div>
        </div>

        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="flex items-center gap-2 bg-gunmetal-800 rounded-lg p-1">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1 rounded text-sm ${
                statusFilter === 'all'
                  ? 'bg-neon-raspberry text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setStatusFilter('profit')}
              className={`px-3 py-1 rounded text-sm ${
                statusFilter === 'profit'
                  ? 'bg-neon-turquoise text-gunmetal-900'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Profit
            </button>
            <button
              onClick={() => setStatusFilter('loss')}
              className={`px-3 py-1 rounded text-sm ${
                statusFilter === 'loss'
                  ? 'bg-neon-pink text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Loss
            </button>
          </div>

          <button
            onClick={() => {}}
            className="p-2 bg-gunmetal-800 rounded-lg text-gray-400 hover:text-neon-raspberry transition-colors"
          >
            <Filter className="w-5 h-5" />
          </button>

          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 bg-gunmetal-800 rounded-lg text-gray-400 hover:text-neon-raspberry transition-colors disabled:opacity-50"
          >
            {refreshing ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <RefreshCw className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      <div className="space-y-6">
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-8 h-8 text-neon-raspberry animate-spin" />
          </div>
        ) : strategies.length === 0 ? (
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 text-neon-yellow mx-auto mb-4" />
            <p className="text-xl text-gray-200 mb-2">No Strategies Found</p>
            <p className="text-gray-400">Create a strategy to start trading</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredStrategies.map((strategy) => {
              const trades = tradeManager.getActiveTradesForStrategy(
                strategy.id
              );
              const isExpanded = expandedStrategies.has(strategy.id);
              const marketState = marketMonitor.getMarketState(
                strategy.strategy_config?.assets?.[0] || ''
              );

              return (
                <motion.div
                  key={`trade-${strategy.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-gunmetal-800/30 rounded-xl overflow-hidden"
                >
                  <div
                    className="p-6 cursor-pointer"
                    onClick={() =>
                      setExpandedStrategies((prev) => {
                        const newSet = new Set(prev);
                        if (newSet.has(strategy.id)) {
                          newSet.delete(strategy.id);
                        } else {
                          newSet.add(strategy.id);
                        }
                        return newSet;
                      })
                    }
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div
                          className={`transform transition-transform ${
                            isExpanded ? 'rotate-180' : ''
                          }`}
                        >
                          <ChevronDown className="w-5 h-5 text-gray-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-200">
                            {strategy.title}
                          </h3>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <BudgetControl
                          strategy={strategy}
                          onSave={handleRefresh}
                        />
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            strategy.status === 'active'
                              ? handleStrategyDeactivate(strategy.id)
                              : handleStrategyActivate(strategy);
                          }}
                          disabled={
                            isSubmittingBudget ||
                            deactivatingStrategy === strategy.id
                          }
                          className={`px-4 py-2 rounded-lg transition-colors ${
                            strategy.status === 'active'
                              ? 'bg-neon-turquoise text-gunmetal-950 hover:bg-neon-yellow'
                              : 'bg-gunmetal-800 text-gray-400 hover:text-neon-turquoise'
                          } disabled:opacity-50`}
                        >
                          {isSubmittingBudget ||
                          deactivatingStrategy === strategy.id ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                          ) : (
                            <div className="flex items-center gap-2">
                              <Power className="w-4 h-4" />
                              <span>
                                {strategy.status === 'active'
                                  ? 'Deactivate'
                                  : 'Activate'}
                              </span>
                            </div>
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mt-4">
                      <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Activity className="w-4 h-4 text-neon-turquoise" />
                          <span className="text-xs text-gray-400">
                            Active Trades
                          </span>
                        </div>
                        <p className="text-lg font-semibold text-gray-200">
                          {trades.length}
                        </p>
                      </div>

                      <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <DollarSign className="w-4 h-4 text-neon-yellow" />
                          <span className="text-xs text-gray-400">
                            Total P&L
                          </span>
                        </div>
                        <p className="text-lg font-semibold text-neon-yellow">
                          +$1,234.56
                        </p>
                      </div>

                      <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Target className="w-4 h-4 text-neon-orange" />
                          <span className="text-xs text-gray-400">
                            Win Rate
                          </span>
                        </div>
                        <p className="text-lg font-semibold text-neon-orange">
                          72.5%
                        </p>
                      </div>

                      <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Clock className="w-4 h-4 text-neon-pink" />
                          <span className="text-xs text-gray-400">
                            Avg Duration
                          </span>
                        </div>
                        <p className="text-lg font-semibold text-neon-pink">
                          3.5h
                        </p>
                      </div>
                    </div>

                    {strategy.status === 'active' && marketState && (
                      <div className="mt-4 grid grid-cols-3 gap-4">
                        <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                          <p className="text-xs text-gray-400 mb-1">
                            Market Trend
                          </p>
                          <div
                            className={`text-sm font-medium ${
                              marketState.trend === 'bullish'
                                ? 'text-neon-turquoise'
                                : marketState.trend === 'bearish'
                                ? 'text-neon-pink'
                                : 'text-neon-yellow'
                            }`}
                          >
                            {marketState.trend.charAt(0).toUpperCase() +
                              marketState.trend.slice(1)}
                          </div>
                        </div>
                        <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                          <p className="text-xs text-gray-400 mb-1">
                            Volatility
                          </p>
                          <div
                            className={`text-sm font-medium ${
                              marketState.volatility === 'high'
                                ? 'text-neon-pink'
                                : marketState.volatility === 'medium'
                                ? 'text-neon-yellow'
                                : 'text-neon-turquoise'
                            }`}
                          >
                            {marketState.volatility.charAt(0).toUpperCase() +
                              marketState.volatility.slice(1)}
                          </div>
                        </div>
                        <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                          <p className="text-xs text-gray-400 mb-1">Volume</p>
                          <div
                            className={`text-sm font-medium ${
                              marketState.volume === 'high'
                                ? 'text-neon-turquoise'
                                : marketState.volume === 'medium'
                                ? 'text-neon-yellow'
                                : 'text-neon-pink'
                            }`}
                          >
                            {marketState.volume.charAt(0).toUpperCase() +
                              marketState.volume.slice(1)}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {expandedStrategies.has(strategy.id) && (
                    <div className="border-t border-gunmetal-700 p-6">
                      {strategy.status === 'active' && (
                        <AssetPairMonitor
                          strategy={strategy}
                          onTradeSignal={(signal) =>
                            handleTradeSignal(strategy, signal)
                          }
                        />
                      )}

                      <div className="mt-6">
                        <h4 className="text-lg font-semibold text-gray-200 mb-4">
                          Active Trades
                        </h4>
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gunmetal-700">
                            <thead className="bg-gunmetal-900/30">
                              <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                                  Pair
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                                  Type
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                                  Entry
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                                  Current
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                                  P&L
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                                  Duration
                                </th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">
                                  Actions
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gunmetal-700">
                              {trades.length === 0 ? (
                                <tr>
                                  <td
                                    colSpan={7}
                                    className="px-6 py-4 text-center text-gray-400"
                                  >
                                    No active trades for this strategy
                                  </td>
                                </tr>
                              ) : (
                                trades.map((trade) => (
                                  <tr
                                    key={trade.id}
                                    className="hover:bg-gunmetal-800/30"
                                  >
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-200">
                                      {trade.pair.replace('_', '/')}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                      <span
                                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                          trade.type === 'Long'
                                            ? 'bg-neon-turquoise/10 text-neon-turquoise'
                                            : 'bg-neon-pink/10 text-neon-pink'
                                        }`}
                                      >
                                        {trade.type === 'Long' ? (
                                          <TrendingUp className="w-3 h-3 mr-1" />
                                        ) : (
                                          <TrendingDown className="w-3 h-3 mr-1" />
                                        )}
                                        {trade.type}
                                      </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-200">
                                      ${trade.entry_price.toFixed(2)}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-200">
                                      ${trade.current_price.toFixed(2)}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                      <div
                                        className={
                                          trade.pnl >= 0
                                            ? 'text-neon-turquoise'
                                            : 'text-neon-pink'
                                        }
                                      >
                                        <span className="text-sm font-medium">
                                          {trade.pnl >= 0 ? '+' : ''}
                                          {trade.pnl.toFixed(2)} USDT
                                        </span>
                                        <span className="text-xs ml-1">
                                          ({trade.pnl_percent >= 0 ? '+' : ''}
                                          {trade.pnl_percent.toFixed(2)}%)
                                        </span>
                                      </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                                      {trade.duration || '0m'}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right">
                                      <button
                                        onClick={() =>
                                          tradeManager.closeTrade(trade.id)
                                        }
                                        className="text-neon-pink hover:text-red-500 transition-colors"
                                      >
                                        <X className="w-5 h-5" />
                                      </button>
                                    </td>
                                  </tr>
                                ))
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {showBudgetModal && pendingStrategy && (
        <BudgetModal
          onConfirm={handleBudgetConfirm}
          onCancel={() => {
            setShowBudgetModal(false);
            setPendingStrategy(null);
          }}
          maxBudget={tradeService.calculateAvailableBudget()}
          riskLevel={pendingStrategy.risk_level}
          isSubmitting={isSubmittingBudget}
        />
      )}
    </div>
  );
};

export default TradeMonitor;
