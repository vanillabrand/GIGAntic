import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  Tag, 
  ChevronLeft, 
  ChevronRight,
  Brain,
  Target,
  Clock,
  DollarSign,
  Gauge,
  AlertCircle,
  Coins,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  BarChart3
} from 'lucide-react';
import type { Strategy } from '../lib/supabase-types';
import { analyticsService } from '../lib/analytics-service';
import { tradeManager } from '../lib/trade-manager';
import { bitmartService } from '../lib/bitmart-service';

interface StrategyStatusProps {
  strategies: Strategy[];
}

export function StrategyStatus({ strategies }: StrategyStatusProps) {
  const [currentPage, setCurrentPage] = useState(0);
  const [assetPrices, setAssetPrices] = useState<Map<string, any>>(new Map());
  const strategiesPerPage = 3;
  const totalPages = Math.ceil(strategies.length / strategiesPerPage);

  useEffect(() => {
    // Subscribe to price updates for all strategy assets
    const assets = new Set<string>();
    strategies.forEach(strategy => {
      if (strategy.strategy_config?.assets) {
        strategy.strategy_config.assets.forEach(asset => assets.add(asset));
      }
    });

    // Initial price fetch
    assets.forEach(async (asset) => {
      try {
        const ticker = await bitmartService.getTicker(asset);
        setAssetPrices(prev => new Map(prev).set(asset, {
          price: parseFloat(ticker.last_price),
          change24h: parseFloat(ticker.change24h || '0')
        }));
        bitmartService.subscribeToSymbol(asset);
      } catch (error) {
        console.error(`Error fetching price for ${asset}:`, error);
      }
    });

    // Subscribe to price updates
    const handlePriceUpdate = (data: any) => {
      setAssetPrices(prev => new Map(prev).set(data.symbol, {
        price: data.price,
        change24h: data.change24h
      }));
    };

    bitmartService.on('priceUpdate', handlePriceUpdate);

    return () => {
      bitmartService.off('priceUpdate', handlePriceUpdate);
      assets.forEach(asset => bitmartService.unsubscribeFromSymbol(asset));
    };
  }, [strategies]);

  // Get current page strategies
  const currentStrategies = strategies.slice(
    currentPage * strategiesPerPage,
    (currentPage + 1) * strategiesPerPage
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Brain className="w-6 h-6 text-neon-raspberry" />
          <h3 className="text-xl font-bold gradient-text">Your Strategies</h3>
        </div>
        
        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setCurrentPage(prev => Math.max(0, prev - 1))}
              disabled={currentPage === 0}
              className="p-2 rounded-lg text-gray-400 hover:text-neon-raspberry transition-colors disabled:opacity-50"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <div className="flex gap-2">
              {Array.from({ length: totalPages }).map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentPage(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentPage
                      ? 'bg-neon-raspberry w-8'
                      : 'bg-gunmetal-700 hover:bg-gunmetal-600'
                  }`}
                />
              ))}
            </div>
            
            <button 
              onClick={() => setCurrentPage(prev => Math.min(totalPages - 1, prev + 1))}
              disabled={currentPage === totalPages - 1}
              className="p-2 rounded-lg text-gray-400 hover:text-neon-raspberry transition-colors disabled:opacity-50"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      {strategies.length === 0 ? (
        <div className="text-center py-8">
          <AlertCircle className="w-12 h-12 text-neon-yellow mx-auto mb-4" />
          <p className="text-xl text-gray-200 mb-2">No Active Strategies</p>
          <p className="text-gray-400">Create your first strategy to start trading</p>
        </div>
      ) : (
        <div className="space-y-4">
          {currentStrategies.map(strategy => {
            const activeTrades = tradeManager.getActiveTradesForStrategy(strategy.id);
            const analytics = analyticsService.getLatestAnalytics(strategy.id);
            const totalPnl = activeTrades.reduce((sum, trade) => sum + trade.pnl, 0);
            const returnRate = analytics?.metrics?.pnl || 0;

            return (
              <motion.div 
                key={strategy.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gunmetal-900/30 rounded-xl p-4"
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="text-lg font-semibold text-gray-200">{strategy.title}</h4>
                    <div className="flex items-center gap-3 mt-1">
                      <span className={`text-sm ${
                        strategy.strategy_config?.market_type === 'futures' 
                          ? 'text-neon-orange' 
                          : 'text-neon-turquoise'
                      }`}>
                        {strategy.strategy_config?.market_type?.toUpperCase() || 'SPOT'}
                      </span>
                      {strategy.strategy_config?.trade_parameters?.leverage > 1 && (
                        <span className="text-sm text-neon-yellow">
                          {strategy.strategy_config.trade_parameters.leverage}x
                        </span>
                      )}
                      <span className="text-sm text-gray-400">
                        {strategy.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-neon-yellow" />
                    <span className="text-sm text-neon-yellow">{strategy.risk_level}</span>
                  </div>
                </div>

                {/* Asset Pairs */}
                {strategy.strategy_config?.assets && (
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    {strategy.strategy_config.assets.map((asset: string) => {
                      const assetData = assetPrices.get(asset);
                      return (
                        <div key={asset} className="bg-gunmetal-800/30 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-gray-200">
                              {asset.replace('_', '/')}
                            </span>
                            {assetData && (
                              <div className={`flex items-center ${
                                assetData.change24h >= 0 ? 'text-neon-turquoise' : 'text-neon-pink'
                              }`}>
                                {assetData.change24h >= 0 ? (
                                  <ArrowUpRight className="w-4 h-4" />
                                ) : (
                                  <ArrowDownRight className="w-4 h-4" />
                                )}
                                <span className="text-xs font-medium">
                                  {assetData.change24h >= 0 ? '+' : ''}{assetData.change24h?.toFixed(2)}%
                                </span>
                              </div>
                            )}
                          </div>
                          {assetData && (
                            <div className="text-lg font-mono font-bold text-gray-200">
                              ${assetData.price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Strategy Metrics */}
                <div className="grid grid-cols-4 gap-4">
                  <div className="bg-gunmetal-800/30 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <Activity className="w-4 h-4 text-neon-turquoise" />
                      <span className="text-xs text-gray-400">Active Trades</span>
                    </div>
                    <p className="text-lg font-semibold text-gray-200">{activeTrades.length}</p>
                  </div>

                  <div className="bg-gunmetal-800/30 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <BarChart3 className="w-4 h-4 text-neon-yellow" />
                      <span className="text-xs text-gray-400">Return Rate</span>
                    </div>
                    <p className={`text-lg font-semibold ${returnRate >= 0 ? 'text-neon-turquoise' : 'text-neon-pink'}`}>
                      {returnRate >= 0 ? '+' : ''}{returnRate.toFixed(2)}%
                    </p>
                  </div>

                  <div className="bg-gunmetal-800/30 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <Wallet className="w-4 h-4 text-neon-orange" />
                      <span className="text-xs text-gray-400">Current P&L</span>
                    </div>
                    <p className={`text-lg font-semibold ${totalPnl >= 0 ? 'text-neon-turquoise' : 'text-neon-pink'}`}>
                      {totalPnl >= 0 ? '+' : ''}{totalPnl.toFixed(2)} USDT
                    </p>
                  </div>

                  <div className="bg-gunmetal-800/30 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <Target className="w-4 h-4 text-neon-pink" />
                      <span className="text-xs text-gray-400">Win Rate</span>
                    </div>
                    <p className="text-lg font-semibold text-neon-pink">
                      {(analytics?.metrics?.winRate || 0).toFixed(1)}%
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}