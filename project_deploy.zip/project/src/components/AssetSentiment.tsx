import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, 
  TrendingUp, 
  TrendingDown, 
  Loader2, 
  RefreshCw,
  Activity,
  Gauge,
  Scale,
  AlertCircle
} from 'lucide-react';
import { bitmartService } from '../lib/bitmart-service';
import { analyticsService } from '../lib/analytics-service';

interface AssetSentimentProps {
  assets: Set<string>;
  className?: string;
}

export function AssetSentiment({ assets, className = "" }: AssetSentimentProps) {
  const [sentiments, setSentiments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    updateSentiments();
    
    // Update every 30 seconds
    const interval = setInterval(updateSentiments, 30000);
    return () => clearInterval(interval);
  }, [assets]);

  const updateSentiments = async () => {
    try {
      setError(null);
      if (!refreshing) setLoading(true);

      let pairs = Array.from(assets);
      if (pairs.length === 0) {
        pairs = ['BTC_USDT', 'ETH_USDT'];
      }

      const sentimentData = await Promise.all(pairs.map(async (symbol) => {
        try {
          // Get real-time data
          const ticker = await bitmartService.getTicker(symbol);
          const price = parseFloat(ticker.last_price);
          const change24h = parseFloat(ticker.change24h || '0');
          
          // Get analytics data
          const analytics = analyticsService.getLatestAnalytics(symbol);
          
          // Calculate sentiment based on multiple factors
          const momentum = analytics?.metrics?.momentum || change24h;
          const volatility = analytics?.metrics?.volatility || Math.abs(change24h);
          const strength = analytics?.metrics?.strength || 50 + (momentum / 2);
          
          let sentiment: 'bullish' | 'bearish' | 'neutral';
          if (momentum > 2 && strength > 60) sentiment = 'bullish';
          else if (momentum < -2 && strength < 40) sentiment = 'bearish';
          else sentiment = 'neutral';

          return {
            symbol: symbol.replace('_', '/'),
            sentiment,
            strength,
            momentum,
            volatility,
            price,
            change24h
          };
        } catch (error) {
          logService.log('error', `Error processing sentiment for ${symbol}:`, error, 'AssetSentiment');
          return null;
        }
      }));

      // Filter out any failed requests
      const validSentiments = sentimentData.filter((data): data is any => data !== null);
      
      if (validSentiments.length === 0) {
        throw new Error('No valid sentiment data available');
      }

      setSentiments(validSentiments);
      setError(null);
    } catch (error) {
      logService.log('error', 'Error updating sentiments:', error, 'AssetSentiment');
      setError('Failed to update market sentiment');
      
      // Generate fallback data
      const fallbackData = Array.from(assets).map(symbol => ({
        symbol: symbol.replace('_', '/'),
        sentiment: 'neutral' as const,
        strength: 50,
        momentum: 0,
        volatility: 5,
        price: symbol.includes('BTC') ? 45000 :
               symbol.includes('ETH') ? 3000 :
               symbol.includes('SOL') ? 100 : 1,
        change24h: 0
      }));
      
      setSentiments(fallbackData);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    updateSentiments();
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'bullish': return 'text-neon-turquoise';
      case 'bearish': return 'text-neon-pink';
      default: return 'text-neon-yellow';
    }
  };

  if (loading && !refreshing) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="w-8 h-8 text-neon-turquoise animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-neon-pink/10 border border-neon-pink/20 rounded-lg p-4 flex items-center gap-3">
        <AlertCircle className="w-5 h-5 text-neon-pink" />
        <p className="text-neon-pink">{error}</p>
      </div>
    );
  }

  return (
    <div className={className}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-neon-yellow" />
          <h3 className="text-lg font-semibold gradient-text">Market Sentiment</h3>
        </div>
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className="p-2 rounded-lg text-gray-400 hover:text-neon-turquoise transition-colors disabled:opacity-50"
        >
          {refreshing ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4" />
          )}
        </button>
      </div>

      <div className="space-y-4">
        {sentiments.map((asset) => (
          <motion.div
            key={asset.symbol}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gunmetal-900/30 rounded-lg p-4"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-lg font-semibold text-gray-200">{asset.symbol}</h4>
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-medium ${getSentimentColor(asset.sentiment)}`}>
                    {asset.sentiment.charAt(0).toUpperCase() + asset.sentiment.slice(1)}
                  </span>
                  <span className="text-gray-400">•</span>
                  <span className={`text-sm ${
                    asset.change24h >= 0 ? 'text-neon-turquoise' : 'text-neon-pink'
                  }`}>
                    {asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(2)}%
                  </span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-mono font-bold text-gray-200">
                  ${asset.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Activity className="w-4 h-4 text-neon-turquoise" />
                  <span className="text-xs text-gray-400">Momentum</span>
                </div>
                <div className="flex items-center gap-2">
                  {asset.momentum >= 0 ? (
                    <TrendingUp className="w-4 h-4 text-neon-turquoise" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-neon-pink" />
                  )}
                  <span className={`text-sm font-medium ${
                    asset.momentum >= 0 ? 'text-neon-turquoise' : 'text-neon-pink'
                  }`}>
                    {Math.abs(asset.momentum).toFixed(1)}
                  </span>
                </div>
              </div>

              <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Gauge className="w-4 h-4 text-neon-yellow" />
                  <span className="text-xs text-gray-400">Strength</span>
                </div>
                <p className="text-sm font-medium text-neon-yellow">
                  {asset.strength.toFixed(1)}%
                </p>
              </div>

              <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Scale className="w-4 h-4 text-neon-orange" />
                  <span className="text-xs text-gray-400">Volatility</span>
                </div>
                <p className="text-sm font-medium text-neon-orange">
                  {asset.volatility.toFixed(1)}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}