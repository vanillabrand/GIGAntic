import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Activity,
  AlertCircle,
  Bug,
  Brain,
  ChevronLeft,
  ChevronRight,
  Clock,
  Coins,
  DollarSign,
  Loader2,
  LogOut,
  Settings as SettingsIcon,
  Shield,
  Target,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Youtube,
  Globe,
  AlertTriangle,
  Calendar
} from 'lucide-react';
import { Auth } from './Auth';
import { useStrategies } from '../hooks/useStrategies';
import { NewsWidget } from './NewsWidget';
import { WorldClock } from './WorldClock';
import { AIMarketInsight } from './AIMarketInsight';
import { PerformanceChart } from './PerformanceChart';
import { RiskExposure } from './RiskExposure';
import { AssetDistribution } from './AssetDistribution';
import { NetworkStatus } from './NetworkStatus';
import { StrategyStatus } from './StrategyStatus';
import { AssetPairsPanel } from './AssetPairsPanel';
import { NewListingsPanel } from './NewListingsPanel';
import { AssetSentiment } from './AssetSentiment';
import { TopPairsPanel } from './TopPairsPanel';

const TIMEZONES = [
  { id: 'UTC', name: 'UTC', offset: 0 },
  { id: 'America/New_York', name: 'New York', offset: -4 },
  { id: 'Europe/London', name: 'London', offset: 1 },
  { id: 'Asia/Tokyo', name: 'Tokyo', offset: 9 },
  { id: 'Asia/Shanghai', name: 'Shanghai', offset: 8 },
  { id: 'Asia/Singapore', name: 'Singapore', offset: 8 }
];

const Dashboard = () => {
  const { strategies } = useStrategies();
  const [selectedTimezone, setSelectedTimezone] = useState('UTC');

  // Memoize active strategies
  const activeStrategies = React.useMemo(() => 
    strategies.filter(s => s.status === 'active'),
    [strategies]
  );

  // Memoize unique assets
  const allAssets = React.useMemo(() => {
    const assets = new Set<string>();
    activeStrategies.forEach(strategy => {
      if (strategy.strategy_config?.assets) {
        strategy.strategy_config.assets.forEach((asset: string) => assets.add(asset));
      }
    });
    return assets;
  }, [activeStrategies]);

  // Get all unique assets for news widget
  const newsAssets = React.useMemo(() => {
    if (Array.from(allAssets).length > 0) {
      return Array.from(allAssets).map(asset => asset.split('_')[0]);
    }
    return ['BTC', 'ETH', 'SOL', 'BNB', 'XRP'];
  }, [allAssets]);

  return (
    <div className="p-6 space-y-[10px]">
      {/* Main Content Grid */}
      <div className="grid grid-cols-12 gap-[10px]">
        {/* Left Column - 7 columns wide */}
        <div className="col-span-12 lg:col-span-7 space-y-[10px]">
          {/* Strategy Status */}
          <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
            <StrategyStatus strategies={strategies} />
          </div>

          {/* Performance Chart */}
          <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
            <PerformanceChart activeStrategies={activeStrategies} />
          </div>

          {/* Risk and Distribution */}
          <div className="grid grid-cols-2 gap-[10px]">
            <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
              <RiskExposure assets={allAssets} />
            </div>
            <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
              <AssetDistribution assets={allAssets} />
            </div>
          </div>

          {/* News Widget */}
          <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
            <NewsWidget assets={newsAssets} limit={4} />
          </div>

          {/* Top Pairs */}
          <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
            <TopPairsPanel assets={allAssets} />
          </div>
        </div>

        {/* Right Column - 5 columns wide */}
        <div className="col-span-12 lg:col-span-5 space-y-[10px]">
          {/* World Clock */}
          <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-neon-turquoise" />
                <select
                  value={selectedTimezone}
                  onChange={(e) => setSelectedTimezone(e.target.value)}
                  className="bg-transparent text-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-neon-turquoise rounded-lg"
                >
                  {TIMEZONES.map(tz => (
                    <option key={tz.id} value={tz.id} className="bg-gunmetal-900">
                      {tz.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-neon-yellow" />
                <span className="text-sm text-gray-200">
                  {new Date().toLocaleDateString(undefined, { 
                    weekday: 'short',
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                  })}
                </span>
              </div>
            </div>
            <WorldClock timezone={selectedTimezone} />
          </div>

          {/* AI Market Insight */}
          <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
            <AIMarketInsight assets={allAssets} />
          </div>

          {/* Asset Sentiment */}
          <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
            <AssetSentiment assets={allAssets} />
          </div>

          {/* New Listings */}
          <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-5">
            <NewListingsPanel />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;