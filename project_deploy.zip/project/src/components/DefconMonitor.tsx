import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';
import useSound from 'use-sound';

interface DefconMonitorProps {
  volatility: number; // 0-100
  className?: string;
}

export function DefconMonitor({ volatility, className = "" }: DefconMonitorProps) {
  const [defconLevel, setDefconLevel] = useState(5);
  const [pulseSpeed, setPulseSpeed] = useState(2);
  const [playKlaxon] = useSound('https://assets.mixkit.co/active_storage/sfx/2894/2894-preview.mp3', { volume: 0.5 });
  const [lastDefconLevel, setLastDefconLevel] = useState(5);

  useEffect(() => {
    // Calculate DEFCON level based on volatility
    const level = volatility >= 80 ? 1 :
                 volatility >= 60 ? 2 :
                 volatility >= 40 ? 3 :
                 volatility >= 20 ? 4 : 5;
    
    setDefconLevel(level);

    // Play klaxon sound when entering DEFCON 1
    if (level === 1 && lastDefconLevel !== 1) {
      playKlaxon();
    }
    setLastDefconLevel(level);

    // Calculate pulse speed (1-5, where 5 is fastest)
    const speed = Math.max(1, Math.min(5, Math.ceil(volatility / 20)));
    setPulseSpeed(speed);
  }, [volatility, lastDefconLevel, playKlaxon]);

  const defconColors = {
    1: 'rgb(239, 68, 68)', // Red
    2: 'rgb(251, 146, 60)', // Orange
    3: 'rgb(34, 197, 94)', // Green
    4: 'rgb(250, 204, 21)', // Yellow
    5: 'rgb(45, 212, 191)' // Cyan
  };

  const pulseAnimation = {
    initial: { 
      opacity: 0.3,
      rotateX: 0,
      scale: 1
    },
    animate: { 
      opacity: [0.3, 1, 0.3],
      rotateX: [0, 360],
      scale: [1, 1.1, 1],
      transition: {
        duration: 6 - pulseSpeed,
        repeat: Infinity,
        ease: [0.455, 0.03, 0.515, 0.955], // easeOutQuad
        times: [0, 0.5, 1]
      }
    }
  };

  const containerVariants = {
    initial: { opacity: 0, scale: 0.9, rotateX: -30 },
    animate: { 
      opacity: 1, 
      scale: 1,
      rotateX: 0,
      transition: {
        duration: 0.8,
        ease: [0.455, 0.03, 0.515, 0.955], // easeOutQuad
        staggerChildren: 0.1
      }
    }
  };

  return (
    <motion.div 
      className={`bg-gunmetal-900/90 backdrop-blur-xl rounded-xl p-6 ${className}`}
      variants={containerVariants}
      initial="initial"
      animate="animate"
      style={{ perspective: 1000 }}
    >
      <div className="flex items-center gap-3 mb-6">
        <AlertTriangle className="w-6 h-6 text-neon-yellow" />
        <h3 className="text-xl font-bold text-gray-200">DEFCON Status</h3>
      </div>

      <div className="grid grid-cols-5 gap-4">
        {[5, 4, 3, 2, 1].map(level => (
          <motion.div
            key={level}
            className="relative aspect-[4/1] rounded transform-gpu"
            style={{
              backgroundColor: defconLevel <= level ? defconColors[level as keyof typeof defconColors] : 'rgb(31, 31, 35)',
              opacity: defconLevel > level ? 0.3 : 1,
              transformStyle: 'preserve-3d'
            }}
            animate={defconLevel === level ? 'animate' : 'initial'}
            variants={pulseAnimation}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-gunmetal-950 font-bold text-sm">
                {level}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div 
        className="mt-4 grid grid-cols-2 gap-4"
        variants={containerVariants}
      >
        <motion.div 
          className="bg-gunmetal-800/50 rounded-lg p-3"
          whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
        >
          <p className="text-sm text-gray-400">Current Level</p>
          <p className="text-2xl font-bold" style={{ color: defconColors[defconLevel as keyof typeof defconColors] }}>
            DEFCON {defconLevel}
          </p>
        </motion.div>
        <motion.div 
          className="bg-gunmetal-800/50 rounded-lg p-3"
          whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
        >
          <p className="text-sm text-gray-400">Market Volatility</p>
          <p className="text-2xl font-bold text-neon-yellow">
            {volatility.toFixed(1)}%
          </p>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}