import React, { useState, useEffect } from 'react';
import { 
  Newspaper, 
  ExternalLink, 
  TrendingUp, 
  TrendingDown, 
  Loader2,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Search,
  Filter,
  SortAsc,
  SortDesc,
  Calendar,
  Tag,
  X
} from 'lucide-react';
import { newsService, type NewsItem } from '../lib/news-service';

interface NewsWidgetProps {
  assets?: string[];
  limit?: number;
}

export function NewsWidget({ assets = [], limit = 10 }: NewsWidgetProps) {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<'date' | 'sentiment' | 'relevance'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null);
  const [selectedSentiment, setSelectedSentiment] = useState<string | null>(null);
  const [showControls, setShowControls] = useState(false);
  const itemsPerPage = 4;

  useEffect(() => {
    fetchNews();
  }, [assets]);

  const fetchNews = async () => {
    try {
      setError(null);
      if (!refreshing) setLoading(true);
      const newsItems = await newsService.getNewsForAssets(assets);
      setNews(newsItems.slice(0, limit));
    } catch (err) {
      setError('Failed to load news');
      console.error('Error fetching news:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchNews();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const getSentimentIcon = (sentiment: string | undefined) => {
    switch (sentiment) {
      case 'positive':
        return <TrendingUp className="w-4 h-4 text-neon-orange" />;
      case 'negative':
        return <TrendingDown className="w-4 h-4 text-neon-pink" />;
      default:
        return null;
    }
  };

  const getAssetColor = (asset: string): string => {
    const assetColors: Record<string, string> = {
      'BTC': 'text-neon-orange',
      'ETH': 'text-neon-turquoise',
      'SOL': 'text-neon-yellow',
      'BNB': 'text-amber-400',
      'XRP': 'text-blue-400',
      'ADA': 'text-indigo-400',
      'DOGE': 'text-yellow-300',
      'MATIC': 'text-purple-400'
    };

    for (const [key, color] of Object.entries(assetColors)) {
      if (asset.includes(key)) {
        return color;
      }
    }
    return 'text-gray-300';
  };

  const truncateDescription = (description: string): string => {
    const firstSentence = description.split('.')[0];
    return firstSentence.length > 120 ? firstSentence.substring(0, 120) + '...' : firstSentence + '.';
  };

  // Get unique assets from all news items
  const uniqueAssets = React.useMemo(() => {
    const assets = new Set<string>();
    news.forEach(item => {
      item.relatedAssets?.forEach(asset => assets.add(asset));
    });
    return Array.from(assets);
  }, [news]);

  // Filter and sort news
  const processedNews = React.useMemo(() => {
    return news
      .filter(item => {
        const searchLower = searchTerm.toLowerCase();
        const matchesSearch = 
          item.title.toLowerCase().includes(searchLower) ||
          item.description.toLowerCase().includes(searchLower) ||
          item.relatedAssets?.some(asset => asset.toLowerCase().includes(searchLower));

        const matchesAsset = !selectedAsset || 
          item.relatedAssets?.some(asset => asset === selectedAsset);

        const matchesSentiment = !selectedSentiment || 
          item.sentiment === selectedSentiment;

        return matchesSearch && matchesAsset && matchesSentiment;
      })
      .sort((a, b) => {
        switch (sortField) {
          case 'date':
            return sortOrder === 'asc'
              ? new Date(a.publishedAt).getTime() - new Date(b.publishedAt).getTime()
              : new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
          case 'sentiment':
            const sentimentValue = (s?: string) => s === 'positive' ? 2 : s === 'negative' ? 0 : 1;
            return sortOrder === 'asc'
              ? sentimentValue(a.sentiment) - sentimentValue(b.sentiment)
              : sentimentValue(b.sentiment) - sentimentValue(a.sentiment);
          case 'relevance':
            const getRelevanceScore = (item: NewsItem) => {
              let score = 0;
              if (item.title.toLowerCase().includes(searchTerm.toLowerCase())) score += 3;
              if (item.description.toLowerCase().includes(searchTerm.toLowerCase())) score += 2;
              if (item.relatedAssets?.some(asset => asset.toLowerCase().includes(searchTerm.toLowerCase()))) score += 1;
              return score;
            };
            return sortOrder === 'asc'
              ? getRelevanceScore(a) - getRelevanceScore(b)
              : getRelevanceScore(b) - getRelevanceScore(a);
          default:
            return 0;
        }
      });
  }, [news, searchTerm, selectedAsset, selectedSentiment, sortField, sortOrder]);

  const totalPages = Math.ceil(processedNews.length / itemsPerPage);
  const displayedNews = processedNews.slice(
    currentPage * itemsPerPage,
    (currentPage + 1) * itemsPerPage
  );

  return (
    <div 
      className="relative"
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Newspaper className="w-6 h-6 text-neon-raspberry" />
          <h2 className="text-xl font-bold gradient-text">Market News</h2>
        </div>
        <button 
          onClick={handleRefresh}
          disabled={refreshing}
          className="p-2 rounded-lg text-gray-400 hover:text-neon-turquoise transition-colors disabled:opacity-50"
        >
          {refreshing ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* Search and Filters - Hidden by default, shown on hover */}
      <div 
        className={`absolute top-16 left-0 right-0 z-10 transition-all duration-300 ${
          showControls ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2 pointer-events-none'
        }`}
      >
        <div className="bg-gunmetal-900/95 backdrop-blur-xl rounded-lg p-4 shadow-lg border border-gunmetal-800">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(0);
                }}
                placeholder="Search news..."
                className="w-full bg-gunmetal-800/50 border border-gunmetal-700 rounded-lg pl-10 pr-4 py-2 text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-neon-turquoise focus:border-transparent"
              />
            </div>

            <div className="flex gap-2">
              {/* Asset Filter */}
              <select
                value={selectedAsset || ''}
                onChange={(e) => {
                  setSelectedAsset(e.target.value || null);
                  setCurrentPage(0);
                }}
                className="bg-gunmetal-800/50 border border-gunmetal-700 rounded-lg px-3 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-turquoise focus:border-transparent"
              >
                <option value="">All Assets</option>
                {uniqueAssets.map(asset => (
                  <option key={asset} value={asset}>{asset}</option>
                ))}
              </select>

              {/* Sentiment Filter */}
              <select
                value={selectedSentiment || ''}
                onChange={(e) => {
                  setSelectedSentiment(e.target.value || null);
                  setCurrentPage(0);
                }}
                className="bg-gunmetal-800/50 border border-gunmetal-700 rounded-lg px-3 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-turquoise focus:border-transparent"
              >
                <option value="">All Sentiment</option>
                <option value="positive">Bullish</option>
                <option value="negative">Bearish</option>
                <option value="neutral">Neutral</option>
              </select>

              {/* Sort Controls */}
              <div className="flex items-center gap-1 bg-gunmetal-800/50 rounded-lg p-1">
                <select
                  value={sortField}
                  onChange={(e) => setSortField(e.target.value as 'date' | 'sentiment' | 'relevance')}
                  className="bg-transparent text-gray-200 px-2 py-1 focus:outline-none"
                >
                  <option value="date">Date</option>
                  <option value="sentiment">Sentiment</option>
                  <option value="relevance">Relevance</option>
                </select>
                <button
                  onClick={() => setSortOrder(order => order === 'asc' ? 'desc' : 'asc')}
                  className="p-1 text-gray-400 hover:text-neon-turquoise transition-colors"
                >
                  {sortOrder === 'asc' ? (
                    <SortAsc className="w-4 h-4" />
                  ) : (
                    <SortDesc className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* News Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {displayedNews.map((item) => (
          <a 
            key={item.id}
            href={item.url}
            target="_blank"
            rel="noopener noreferrer"
            className="group block bg-gunmetal-900/30 rounded-lg p-6 hover:bg-gunmetal-800/30 transition-all duration-300 border border-gunmetal-800/50 hover:border-neon-raspberry/30"
          >
            {/* Asset Tags */}
            <div className="flex flex-wrap gap-2 mb-3">
              {item.relatedAssets?.slice(0, 3).map((asset) => (
                <span 
                  key={asset} 
                  className={`px-2 py-0.5 text-xs font-medium bg-gunmetal-900/50 rounded-full ${getAssetColor(asset)}`}
                >
                  {asset}
                </span>
              ))}
            </div>
            
            <h4 className="text-lg font-medium text-gray-200 mb-3 line-clamp-2">{item.title}</h4>
            <p className="text-sm text-gray-400 mb-4 line-clamp-2">{truncateDescription(item.description)}</p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-sm text-gray-400">
                  <Calendar className="w-4 h-4" />
                  {formatDate(item.publishedAt)}
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-sm text-gray-400">{item.source}</span>
                  {getSentimentIcon(item.sentiment)}
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </a>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-4 mt-6">
          <button
            onClick={() => setCurrentPage(prev => Math.max(0, prev - 1))}
            disabled={currentPage === 0}
            className="p-2 rounded-lg bg-gunmetal-800 text-gray-400 hover:text-neon-turquoise transition-colors disabled:opacity-50"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          
          <div className="flex gap-2">
            {Array.from({ length: totalPages }).map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentPage(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentPage
                    ? 'bg-neon-raspberry w-8'
                    : 'bg-gunmetal-700 hover:bg-gunmetal-600'
                }`}
              />
            ))}
          </div>
          
          <button
            onClick={() => setCurrentPage(prev => Math.min(totalPages - 1, prev + 1))}
            disabled={currentPage === totalPages - 1}
            className="p-2 rounded-lg bg-gunmetal-800 text-gray-400 hover:text-neon-turquoise transition-colors disabled:opacity-50"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}