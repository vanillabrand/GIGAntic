import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Brain,
  TrendingUp,
  Shield,
  Target,
  ChevronLeft,
  ChevronRight,
  Gauge,
  Zap,
  Crown,
  Scale,
  AlertTriangle,
  Check,
  Loader2,
  Search,
  Filter,
  SortAsc,
  SortDesc,
} from 'lucide-react';
import { useAuth } from '../lib/auth-context';
import { strategyService } from '../lib/strategy-service';
import { templateService } from '../lib/template-service';
import type { StrategyTemplate } from '../lib/types';

interface StrategyTemplatesProps {
  onStrategyCreated?: () => void;
  className?: string;
}

export function StrategyTemplates({
  onStrategyCreated,
  className = '',
}: StrategyTemplatesProps) {
  const { user } = useAuth();
  const [templates, setTemplates] = useState<StrategyTemplate[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [creatingStrategy, setCreatingStrategy] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState<string | null>(null);
  const [sortField, setSortField] = useState<'winRate' | 'avgReturn'>(
    'winRate'
  );
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const templatesPerPage = 6;

  useEffect(() => {
    if (user) {
      loadTemplates();
    }
  }, [user]);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      setError(null);

      if (!user) {
        throw new Error('User not authenticated');
      }

      const userTemplates = await templateService.getTemplatesForUser(user.id);
      setTemplates(userTemplates);
    } catch (err) {
      setError('Failed to load strategy templates');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUseTemplate = async (template: StrategyTemplate) => {
    if (!user) return;

    try {
      setCreatingStrategy(template.id);

      // Create new strategy from template
      await strategyService.createStrategy({
        title: template.title,
        description: template.description,
        risk_level: template.risk_level,
        user_id: user.id,
        strategy_config: template.config,
      });

      onStrategyCreated?.();
    } catch (err) {
      console.error('Error creating strategy from template:', err);
      setError('Failed to create strategy from template');
    } finally {
      setCreatingStrategy(null);
    }
  };

  const filteredTemplates = React.useMemo(() => {
    return templates
      .filter((template) => {
        const matchesSearch =
          template.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          template.description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRisk = !riskFilter || template.risk_level === riskFilter;
        return matchesSearch && matchesRisk;
      })
      .sort((a, b) => {
        const field = sortField === 'winRate' ? 'winRate' : 'avgReturn';
        const comparison = (a.metrics[field] || 0) - (b.metrics[field] || 0);
        return sortOrder === 'asc' ? comparison : -comparison;
      });
  }, [templates, searchTerm, riskFilter, sortField, sortOrder]);

  const totalPages = Math.ceil(filteredTemplates.length / templatesPerPage);
  const displayedTemplates = filteredTemplates.slice(
    currentPage * templatesPerPage,
    (currentPage + 1) * templatesPerPage
  );

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'Ultra Low':
        return Shield;
      case 'Low':
        return Scale;
      case 'Medium':
        return Gauge;
      case 'High':
        return TrendingUp;
      case 'Ultra High':
        return Zap;
      case 'Extreme':
        return AlertTriangle;
      case 'God Mode':
        return Crown;
      default:
        return Brain;
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Ultra Low':
        return 'text-emerald-400';
      case 'Low':
        return 'text-green-400';
      case 'Medium':
        return 'text-blue-400';
      case 'High':
        return 'text-orange-400';
      case 'Ultra High':
        return 'text-red-400';
      case 'Extreme':
        return 'text-purple-400';
      case 'God Mode':
        return 'text-yellow-400';
      default:
        return 'text-gray-400';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="w-8 h-8 text-neon-raspberry animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <AlertCircle className="w-12 h-12 text-neon-pink mx-auto mb-4" />
        <p className="text-neon-pink">{error}</p>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Filters and Search */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search templates..."
            className="w-full bg-gunmetal-800 border border-gunmetal-700 rounded-lg pl-10 pr-4 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-raspberry focus:border-transparent"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={riskFilter || ''}
            onChange={(e) => setRiskFilter(e.target.value || null)}
            className="bg-gunmetal-800 border border-gunmetal-700 rounded-lg px-4 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-raspberry focus:border-transparent"
          >
            <option value="">All Risk Levels</option>
            <option value="Ultra Low">Ultra Low</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
            <option value="Ultra High">Ultra High</option>
            <option value="Extreme">Extreme</option>
            <option value="God Mode">God Mode</option>
          </select>

          <button
            onClick={() =>
              setSortOrder((order) => (order === 'asc' ? 'desc' : 'asc'))
            }
            className="p-2 bg-gunmetal-800 rounded-lg text-gray-400 hover:text-neon-turquoise transition-colors"
          >
            {sortOrder === 'asc' ? (
              <SortAsc className="w-5 h-5" />
            ) : (
              <SortDesc className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayedTemplates.map((template) => {
          const RiskIcon = getRiskIcon(template.risk_level);
          const riskColor = getRiskColor(template.risk_level);

          return (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-gunmetal-800/30 rounded-xl p-6 hover:bg-gunmetal-800/50 transition-all duration-300 border border-gunmetal-700"
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className={`p-2 rounded-lg bg-gunmetal-900/50 ${riskColor}`}
                  >
                    <RiskIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-200">
                      {template.title}
                    </h3>
                    <p className={`text-sm ${riskColor}`}>
                      {template.risk_level}
                    </p>
                  </div>
                </div>

                <p className="text-sm text-gray-400 mb-4 flex-grow line-clamp-2">
                  {template.description}
                </p>

                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="bg-gunmetal-900/30 rounded-lg p-2">
                    <p className="text-xs text-gray-400">Win Rate</p>
                    <p className="text-sm font-medium text-neon-turquoise">
                      {Number(template.metrics.winRate).toFixed(1)}%
                    </p>
                  </div>
                  <div className="bg-gunmetal-900/30 rounded-lg p-2">
                    <p className="text-xs text-gray-400">Avg Return</p>
                    <p className="text-sm font-medium text-neon-orange">
                      {Number(template.metrics.avgReturn).toFixed(1)}%
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleUseTemplate(template)}
                  disabled={creatingStrategy === template.id}
                  className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-gunmetal-900/30 rounded-lg text-gray-400 hover:text-neon-turquoise transition-all duration-300 disabled:opacity-50"
                >
                  {creatingStrategy === template.id ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      Use Template
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-4 mt-6">
          <button
            onClick={() => setCurrentPage((prev) => Math.max(0, prev - 1))}
            disabled={currentPage === 0}
            className="p-2 rounded-lg bg-gunmetal-800 text-gray-400 hover:text-neon-turquoise transition-colors disabled:opacity-50"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex gap-2">
            {Array.from({ length: totalPages }).map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentPage(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentPage
                    ? 'bg-neon-raspberry w-8'
                    : 'bg-gunmetal-700 hover:bg-gunmetal-600'
                }`}
              />
            ))}
          </div>

          <button
            onClick={() =>
              setCurrentPage((prev) => Math.min(totalPages - 1, prev + 1))
            }
            disabled={currentPage === totalPages - 1}
            className="p-2 rounded-lg bg-gunmetal-800 text-gray-400 hover:text-neon-turquoise transition-colors disabled:opacity-50"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}
