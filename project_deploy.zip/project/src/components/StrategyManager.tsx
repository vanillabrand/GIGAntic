import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Activity,
  AlertCircle,
  Bug,
  Brain,
  ChevronLeft,
  ChevronRight,
  Clock,
  Coins,
  DollarSign,
  Loader2,
  LogOut,
  MessageSquare,
  Plus,
  Send,
  Shield,
  Trash,
  Trash2,
  X,
  Power,
  Target,
  Gauge,
  Search,
  Filter,
  SortAsc,
  SortDesc,
} from 'lucide-react';
import { useStrategies } from '../hooks/useStrategies';
import { marketService } from '../lib/market-service';
import { StrategyEditor } from './StrategyEditor';
import { DeleteConfirmation } from './DeleteConfirmation';
import { StrategyPerformanceReport } from './StrategyPerformanceReport';
import { BudgetModal } from './BudgetModal';
import { StrategyLibrary } from './StrategyLibrary';
import { tradeService } from '../lib/trade-service';
import { tradeManager } from '../lib/trade-manager';
import { logService } from '../lib/log-service';
import { aiService } from '../lib/ai-service';
import type { Strategy } from '../lib/supabase-types';
import type { StrategyBudget, StrategyTemplate } from '../lib/types';
import { DeleteAllConfirmation } from './DeleteAllConfirmation';

const StrategyManager = () => {
  const {
    strategies,
    loading,
    createStrategy,
    updateStrategy,
    deleteStrategy,
    clearAllStrategies,
    refresh,
  } = useStrategies();
  const [isCreating, setIsCreating] = useState(false);
  const [strategyTitle, setStrategyTitle] = useState('');
  const [strategyInput, setStrategyInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStep, setGenerationStep] = useState('');
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null);
  const [showBudgetModal, setShowBudgetModal] = useState(false);
  const [editingStrategy, setEditingStrategy] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(
    null
  );
  const [showPerformanceReport, setShowPerformanceReport] = useState<
    string | null
  >(null);
  const [viewingStrategy, setViewingStrategy] = useState<string | null>(null);
  const [showDeleteAllConfirm, setShowDeleteAllConfirm] = useState(false);
  const [isDeletingAll, setIsDeletingAll] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [isDeletingStrategy, setIsDeletingStrategy] = useState<string | null>(
    null
  );
  const [creatingStrategy, setCreatingStrategy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pendingStrategy, setPendingStrategy] = useState<Strategy | null>(null);
  const [isSubmittingBudget, setIsSubmittingBudget] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<
    'title' | 'performance' | 'risk_level' | 'created_at'
  >('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [riskFilter, setRiskFilter] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(0);
  const [pulsingStrategy, setPulsingStrategy] = useState<string | null>(null);
  const [pulseColor, setPulseColor] = useState<
    'activate' | 'trade' | 'deactivate' | null
  >(null);

  const ITEMS_PER_PAGE = 5;

  // Filter and sort strategies
  const filteredStrategies = React.useMemo(() => {
    return strategies
      .filter((s) => {
        const matchesSearch =
          s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.description?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRisk = !riskFilter || s.risk_level === riskFilter;
        return matchesSearch && matchesRisk;
      })
      .sort((a, b) => {
        let comparison = 0;
        switch (sortField) {
          case 'title':
            comparison = a.title.localeCompare(b.title);
            break;
          case 'performance':
            comparison = (a.performance || 0) - (b.performance || 0);
            break;
          case 'risk_level':
            comparison = a.risk_level.localeCompare(b.risk_level);
            break;
          case 'created_at':
            comparison =
              new Date(a.created_at).getTime() -
              new Date(b.created_at).getTime();
            break;
        }
        return sortOrder === 'asc' ? comparison : -comparison;
      });
  }, [strategies, searchTerm, sortField, sortOrder, riskFilter]);

  // Calculate pagination
  const totalPages = Math.ceil(filteredStrategies.length / ITEMS_PER_PAGE);
  const paginatedStrategies = filteredStrategies.slice(
    currentPage * ITEMS_PER_PAGE,
    (currentPage + 1) * ITEMS_PER_PAGE
  );

  const handleBudgetConfirm = async (budget: StrategyBudget) => {
    if (!selectedStrategy && !pendingStrategy) return;

    try {
      setError(null);
      setIsSubmittingBudget(true);
      const strategy =
        pendingStrategy || strategies.find((s) => s.id === selectedStrategy);
      if (!strategy) throw new Error('Strategy not found');

      // First set the budget
      await tradeService.setBudget(strategy.id, budget);

      // Then start the strategy monitoring
      await marketService.startStrategyMonitoring(strategy);

      // Finally update the strategy status
      await updateStrategy(strategy.id, {
        status: 'active',
        updated_at: new Date().toISOString(),
      });

      // Clear all modal-related state
      setShowBudgetModal(false);
      setSelectedStrategy(null);
      setPendingStrategy(null);
      setPulsingStrategy(strategy.id);
      setPulseColor('activate');

      setTimeout(() => {
        setPulsingStrategy(null);
        setPulseColor(null);
      }, 2000);

      // Refresh strategies list
      refresh();

      logService.log(
        'info',
        `Strategy ${strategy.id} activated with budget`,
        { budget },
        'StrategyManager'
      );
    } catch (error) {
      logService.log(
        'error',
        'Failed to start strategy with budget',
        error,
        'StrategyManager'
      );
      setError('Failed to activate strategy. Please try again.');

      // Clean up on failure
      if (selectedStrategy) {
        await tradeService.setBudget(selectedStrategy, null);
      }
    } finally {
      setIsSubmittingBudget(false);
    }
  };

  const handleTemplateSelected = async (template: StrategyTemplate) => {
    try {
      setError(null);
      setCreatingStrategy(template.id);

      // Create strategy from template
      const strategy = await createStrategy({
        title: template.title,
        description: template.description,
        risk_level: template.risk_level,
      });

      // Show success animation
      setPulsingStrategy(strategy.id);
      setPulseColor('activate');
      setTimeout(() => {
        setPulsingStrategy(null);
        setPulseColor(null);
      }, 2000);

      // Refresh strategies list
      refresh();

      logService.log(
        'info',
        `Created strategy from template ${template.id}`,
        strategy,
        'StrategyManager'
      );
    } catch (error) {
      const errorMessage =
        error instanceof Error
          ? error.message
          : 'Failed to create strategy from template';
      setError(errorMessage);
      logService.log(
        'error',
        'Error creating strategy from template:',
        error,
        'StrategyManager'
      );
    } finally {
      setCreatingStrategy(null);
    }
  };

  const handleCreateStrategy = async () => {
    if (!strategyTitle || !strategyInput) {
      setError('Please provide both a title and description for your strategy');
      return;
    }

    try {
      setIsGenerating(true);
      setGenerationError(null);
      setGenerationProgress(0);
      setGenerationStep('Analyzing strategy description...');

      // Generate strategy configuration with AI
      const strategyConfig = await aiService.generateStrategy(
        strategyInput,
        'Medium'
      );

      // Create the strategy
      const strategy = await createStrategy({
        title: strategyTitle,
        description: strategyInput,
        risk_level: 'Medium', // Default risk level
        strategy_config: strategyConfig,
      });

      setGenerationStep('Strategy created successfully!');
      setGenerationProgress(100);
      setIsCreating(false);
      setStrategyTitle('');
      setStrategyInput('');

      // Show success animation
      setPulsingStrategy(strategy.id);
      setPulseColor('activate');
      setTimeout(() => {
        setPulsingStrategy(null);
        setPulseColor(null);
      }, 2000);

      // Refresh strategies list
      refresh();
    } catch (error) {
      setGenerationError(
        error instanceof Error ? error.message : 'Failed to create strategy'
      );
      logService.log(
        'error',
        'Failed to create strategy:',
        error,
        'StrategyManager'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleStrategyDelete = async (strategyId: string) => {
    try {
      setIsDeletingStrategy(strategyId);

      // First stop monitoring if active
      const strategy = strategies.find((s) => s.id === strategyId);
      if (strategy?.status === 'active') {
        await marketService.stopStrategyMonitoring(strategyId);
      }

      // Then delete the strategy
      await deleteStrategy(strategyId);
      setShowDeleteConfirm(null);

      // Refresh strategies list
      refresh();

      logService.log(
        'info',
        `Strategy ${strategyId} deleted successfully`,
        null,
        'StrategyManager'
      );
    } catch (error) {
      setError('Failed to delete strategy');
      logService.log(
        'error',
        `Failed to delete strategy ${strategyId}:`,
        error,
        'StrategyManager'
      );
    } finally {
      setIsDeletingStrategy(null);
    }
  };

  const handleStrategyDeactivate = async (strategy: Strategy) => {
    try {
      await marketService.stopStrategyMonitoring(strategy.id);
      await updateStrategy(strategy.id, {
        status: 'inactive',
        updated_at: new Date().toISOString(),
      });

      // Refresh strategies list
      refresh();

      setShowPerformanceReport(null);
    } catch (error) {
      setError('Failed to deactivate strategy');
      logService.log(
        'error',
        `Failed to deactivate strategy ${strategy.id}:`,
        error,
        'StrategyManager'
      );
    }
  };

  return (
    <div className="p-8 space-y-6">
      {/* Section Description */}
      <div className="bg-gunmetal-800/20 rounded-xl p-4 mb-6">
        <h2 className="text-lg font-semibold text-gray-200 mb-2">
          Strategy Manager
        </h2>
        <p className="text-sm text-gray-400">
          Create and manage your trading strategies. Use AI to generate new
          strategies or customize existing ones.
        </p>
      </div>

      {/* Create Your Own Strategy */}
      <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-6 border border-gunmetal-800 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Brain className="w-6 h-6 text-neon-raspberry" />
            <h2 className="text-xl font-bold gradient-text">
              Create Your Own Strategy
            </h2>
          </div>
          <button
            onClick={() => setIsCreating(true)}
            className="flex items-center gap-2 px-4 py-2 bg-neon-raspberry text-white rounded-lg hover:bg-[#FF69B4] transition-all duration-300"
          >
            <Plus className="w-4 h-4" />
            Create Strategy
          </button>
        </div>

        <p className="text-gray-300 mb-4">
          Design your own custom trading strategy using our AI-powered strategy
          generator. Simply describe your strategy in plain English, and our AI
          will translate it into executable trading rules.
        </p>
      </div>

      {/* Strategy Library */}
      <StrategyLibrary
        onTemplateSelect={handleTemplateSelected}
        className="mb-8"
      />

      {/* Existing Strategies */}
      <div className="bg-gradient-to-br from-gunmetal-900/90 to-gunmetal-800/90 backdrop-blur-xl rounded-xl p-6 border border-gunmetal-800">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold gradient-text">Your Strategies</h2>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search strategies..."
                className="w-64 bg-gunmetal-800 border border-gunmetal-700 rounded-lg pl-10 pr-4 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-raspberry focus:border-transparent"
              />
            </div>

            <select
              value={riskFilter || ''}
              onChange={(e) => setRiskFilter(e.target.value || null)}
              className="bg-gunmetal-800 border border-gunmetal-700 rounded-lg px-4 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-raspberry focus:border-transparent"
            >
              <option value="">All Risk Levels</option>
              <option value="Ultra Low">Ultra Low</option>
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
              <option value="Ultra High">Ultra High</option>
              <option value="Extreme">Extreme</option>
              <option value="God Mode">God Mode</option>
            </select>

            <button
              onClick={() =>
                setSortOrder((order) => (order === 'asc' ? 'desc' : 'asc'))
              }
              className="p-2 bg-gunmetal-800 rounded-lg text-gray-400 hover:text-neon-turquoise transition-colors"
            >
              {sortOrder === 'asc' ? (
                <SortAsc className="w-5 h-5" />
              ) : (
                <SortDesc className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-8 h-8 text-neon-raspberry animate-spin" />
          </div>
        ) : strategies.length === 0 ? (
          <div className="text-center py-12">
            <Brain className="w-12 h-12 text-neon-yellow mx-auto mb-4" />
            <p className="text-xl text-gray-200 mb-2">No Strategies Yet</p>
            <p className="text-gray-400">
              Create your first strategy to start trading
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {paginatedStrategies.map((strategy) => (
              <motion.div
                key={strategy.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`bg-gunmetal-800/30 rounded-xl p-6 border border-gunmetal-700 transition-all duration-300 ${
                  pulsingStrategy === strategy.id
                    ? `animate-pulse border-${pulseColor}`
                    : ''
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-200">
                      {strategy.title}
                    </h3>
                    <p className="text-sm text-gray-400">
                      {strategy.description}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setEditingStrategy(strategy.id)}
                      className="p-2 text-gray-400 hover:text-neon-yellow transition-colors"
                    >
                      <Gauge className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4">
                  <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                    <p className="text-xs text-gray-400">Risk Level</p>
                    <p className="text-sm font-medium text-neon-yellow">
                      {strategy.risk_level}
                    </p>
                  </div>
                  <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                    <p className="text-xs text-gray-400">Performance</p>
                    <p
                      className={`text-sm font-medium ${
                        (strategy.performance || 0) >= 0
                          ? 'text-neon-turquoise'
                          : 'text-neon-pink'
                      }`}
                    >
                      {(strategy.performance || 0).toFixed(2)}%
                    </p>
                  </div>
                  <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                    <p className="text-xs text-gray-400">Trading Pairs</p>
                    <p className="text-sm font-medium text-neon-orange">
                      {strategy.strategy_config?.assets?.length || 0}
                    </p>
                  </div>
                  <div className="bg-gunmetal-900/30 p-3 rounded-lg">
                    <p className="text-xs text-gray-400">Created</p>
                    <p className="text-sm font-medium text-gray-300">
                      {new Date(strategy.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center gap-4 mt-6">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(0, prev - 1))}
              disabled={currentPage === 0}
              className="p-2 rounded-lg bg-gunmetal-800 text-gray-400 hover:text-neon-turquoise transition-colors disabled:opacity-50"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <div className="flex gap-2">
              {Array.from({ length: totalPages }).map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentPage(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentPage
                      ? 'bg-neon-raspberry w-8'
                      : 'bg-gunmetal-700 hover:bg-gunmetal-600'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={() =>
                setCurrentPage((prev) => Math.min(totalPages - 1, prev + 1))
              }
              disabled={currentPage === totalPages - 1}
              className="p-2 rounded-lg bg-gunmetal-800 text-gray-400 hover:text-neon-turquoise transition-colors disabled:opacity-50"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      {/* Modals */}
      {showBudgetModal && (
        <BudgetModal
          onConfirm={handleBudgetConfirm}
          onCancel={() => {
            setShowBudgetModal(false);
            setSelectedStrategy(null);
            setPendingStrategy(null);
          }}
          maxBudget={tradeService.calculateAvailableBudget()}
          riskLevel={
            selectedStrategy
              ? strategies.find((s) => s.id === selectedStrategy)?.risk_level ||
                'Medium'
              : pendingStrategy?.risk_level || 'Medium'
          }
          isSubmitting={isSubmittingBudget}
        />
      )}

      {showDeleteConfirm && (
        <DeleteConfirmation
          onConfirm={() => handleStrategyDelete(showDeleteConfirm)}
          onCancel={() => setShowDeleteConfirm(null)}
          name={strategies.find((s) => s.id === showDeleteConfirm)?.title || ''}
          isDeleting={isDeletingStrategy === showDeleteConfirm}
        />
      )}

      {showDeleteAllConfirm && (
        <DeleteAllConfirmation
          onConfirm={async () => {
            try {
              setIsDeletingAll(true);
              await clearAllStrategies();
              setShowDeleteAllConfirm(false);
              refresh(); // Refresh after clearing all
            } catch (error) {
              setDeleteError('Failed to delete all strategies');
            } finally {
              setIsDeletingAll(false);
            }
          }}
          onCancel={() => setShowDeleteAllConfirm(false)}
          isDeleting={isDeletingAll}
          error={deleteError}
        />
      )}

      {showPerformanceReport && (
        <StrategyPerformanceReport
          performance={marketService.getStrategyPerformance(
            showPerformanceReport
          )}
          onClose={() => setShowPerformanceReport(null)}
          onConfirm={async () => {
            const strategy = strategies.find(
              (s) => s.id === showPerformanceReport
            );
            if (strategy) {
              await handleStrategyDeactivate(strategy);
            }
          }}
          strategyName={
            strategies.find((s) => s.id === showPerformanceReport)?.title || ''
          }
        />
      )}

      {editingStrategy && (
        <StrategyEditor
          strategy={strategies.find((s) => s.id === editingStrategy)!}
          onSave={async (updates) => {
            try {
              await updateStrategy(editingStrategy, updates);
              setEditingStrategy(null);
              refresh(); // Refresh after update
            } catch (error) {
              setError('Failed to update strategy');
            }
          }}
          isEditing={true}
          onClose={() => setEditingStrategy(null)}
        />
      )}

      {/* Create Strategy Form */}
      {isCreating && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gunmetal-900/90 backdrop-blur-xl rounded-xl p-6 w-full max-w-2xl border border-gunmetal-800">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Brain className="w-6 h-6 text-neon-raspberry" />
                <h2 className="text-xl font-bold gradient-text">
                  Create Your Strategy
                </h2>
              </div>
              <button
                onClick={() => setIsCreating(false)}
                className="text-gray-400 hover:text-gray-200"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {generationError && (
              <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-2 text-red-400">
                <AlertCircle className="w-5 h-5" />
                {generationError}
              </div>
            )}

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Strategy Name
                </label>
                <input
                  type="text"
                  value={strategyTitle}
                  onChange={(e) => setStrategyTitle(e.target.value)}
                  className="w-full bg-gunmetal-800 border border-gunmetal-700 rounded-lg px-4 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-raspberry focus:border-transparent"
                  placeholder="e.g., RSI Momentum Strategy"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Describe Your Strategy
                </label>
                <textarea
                  value={strategyInput}
                  onChange={(e) => setStrategyInput(e.target.value)}
                  className="w-full h-32 bg-gunmetal-800 border border-gunmetal-700 rounded-lg px-4 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-neon-raspberry focus:border-transparent"
                  placeholder="Describe your trading strategy in plain English. For example: Buy when RSI crosses above 30 and sell when it crosses below 70. Focus on BTC and ETH with medium risk tolerance."
                />
              </div>

              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setIsCreating(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-400 hover:text-gray-200"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateStrategy}
                  disabled={isGenerating || !strategyTitle || !strategyInput}
                  className="flex items-center gap-2 px-4 py-2 bg-neon-raspberry text-white rounded-lg hover:bg-[#FF69B4] transition-all duration-300 disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      Create Strategy
                    </>
                  )}
                </button>
              </div>

              {isGenerating && (
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-400">{generationStep}</span>
                    <span className="text-neon-turquoise">
                      {generationProgress}%
                    </span>
                  </div>
                  <div className="w-full bg-gunmetal-800 rounded-full h-2">
                    <div
                      className="h-2 rounded-full bg-neon-turquoise transition-all duration-300"
                      style={{ width: `${generationProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StrategyManager;
