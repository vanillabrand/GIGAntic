import CryptoJS from 'crypto-js';
import { websocketService } from './websocket-service';
import { EventEmitter } from './event-emitter';
import { logService } from './log-service';

interface BitmartConfig {
  apiKey: string;
  secret: string;
  memo: string;
  testnet?: boolean;
  useUSDX?: boolean;
}

interface BitmartTicker {
  symbol: string;
  last_price: string;
  quote_volume_24h: string;
  base_volume_24h: string;
  high_24h: string;
  low_24h: string;
  open_24h: string;
  timestamp: number;
}

interface BitmartKline {
  timestamp: number;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
}

interface BitmartBalance {
  total: number;
  available: number;
  frozen: number;
}

interface AssetData {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  high24h: number;
  low24h: number;
  lastUpdate: number;
  priceHistory: { timestamp: number; price: number }[];
}

class BitmartService extends EventEmitter {
  private static instance: BitmartService;
  private config: BitmartConfig | null = null;
  private baseUrl = 'https://api-cloud.bitmart.com';
  private demoMode = false;
  private useUSDX = false;
  private assetData = new Map<string, AssetData>();
  private subscriptions = new Set<string>();
  private initialized = false;
  private updateInterval: NodeJS.Timeout | null = null;
  private readonly UPDATE_INTERVAL = 5000; // 5 seconds
  private readonly DEFAULT_ASSETS = ['BTC_USDT', 'ETH_USDT', 'SOL_USDT', 'BNB_USDT', 'XRP_USDT'];
  private readonly HISTORY_POINTS = 60; // Keep 60 points for 1 hour of data
  private readonly HISTORY_INTERVAL = 60000; // 1 minute intervals

  private constructor() {
    super();
    this.setupWebSocket();
  }

  private setupWebSocket(): void {
    websocketService.on('ticker', (data) => {
      if (!data || !data.symbol) return;

      const price = parseFloat(data.last_price);
      if (isNaN(price)) return;

      const open24h = parseFloat(data.open_24h || '0');
      const change24h = open24h ? ((price - open24h) / open24h) * 100 : 0;
      const volume24h = parseFloat(data.quote_volume_24h || '0');
      const high24h = parseFloat(data.high_24h || price);
      const low24h = parseFloat(data.low_24h || price);
      const now = Date.now();

      // Get existing data or create new
      const existingData = this.assetData.get(data.symbol) || {
        symbol: data.symbol,
        price: 0,
        change24h: 0,
        volume24h: 0,
        high24h: 0,
        low24h: 0,
        lastUpdate: 0,
        priceHistory: []
      };

      // Update price history
      const newHistory = [...existingData.priceHistory];
      
      // Remove data points older than 1 hour
      const hourAgo = now - 3600000;
      while (newHistory.length > 0 && newHistory[0].timestamp < hourAgo) {
        newHistory.shift();
      }

      // Add new price point if enough time has passed
      if (newHistory.length === 0 || now - newHistory[newHistory.length - 1].timestamp >= this.HISTORY_INTERVAL) {
        newHistory.push({ timestamp: now, price });
      }

      // Update asset data
      const assetData: AssetData = {
        symbol: data.symbol,
        price,
        change24h,
        volume24h,
        high24h,
        low24h,
        lastUpdate: now,
        priceHistory: newHistory
      };

      this.assetData.set(data.symbol, assetData);
      this.emit('priceUpdate', assetData);
    });
  }

  static getInstance(): BitmartService {
    if (!BitmartService.instance) {
      BitmartService.instance = new BitmartService();
    }
    return BitmartService.instance;
  }

  initialize(config: BitmartConfig): void {
    this.config = config;
    this.demoMode = config.apiKey === 'demo';
    this.useUSDX = config.useUSDX || false;
    this.baseUrl = config.testnet ? 'https://api-cloud.bitmart.test' : 'https://api-cloud.bitmart.com';
    this.initialized = true;

    // Initialize with default assets in demo mode
    if (this.demoMode) {
      this.DEFAULT_ASSETS.forEach(symbol => this.subscribeToSymbol(symbol));
    }

    // Start periodic updates
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
    this.updateInterval = setInterval(() => this.updateAssetData(), this.UPDATE_INTERVAL);

    // Connect WebSocket
    websocketService.connect();

    logService.log('info', `Initialized BitMart service in ${this.demoMode ? 'demo' : 'live'} mode`, null, 'BitmartService');
  }

  private async updateAssetData(): Promise<void> {
    try {
      const symbols = this.demoMode ? this.DEFAULT_ASSETS : Array.from(this.subscriptions);
      const now = Date.now();
      
      for (const symbol of symbols) {
        const ticker = await this.getTicker(symbol);
        const price = parseFloat(ticker.last_price);
        const open24h = parseFloat(ticker.open_24h || '0');
        const change24h = open24h ? ((price - open24h) / open24h) * 100 : 0;

        // Get existing data or create new
        const existingData = this.assetData.get(symbol) || {
          symbol,
          price: 0,
          change24h: 0,
          volume24h: 0,
          high24h: 0,
          low24h: 0,
          lastUpdate: 0,
          priceHistory: []
        };

        // Update price history
        const newHistory = [...existingData.priceHistory];
        
        // Remove data points older than 1 hour
        const hourAgo = now - 3600000;
        while (newHistory.length > 0 && newHistory[0].timestamp < hourAgo) {
          newHistory.shift();
        }

        // Add new price point if enough time has passed
        if (newHistory.length === 0 || now - newHistory[newHistory.length - 1].timestamp >= this.HISTORY_INTERVAL) {
          newHistory.push({ timestamp: now, price });
        }

        const assetData: AssetData = {
          symbol,
          price,
          change24h,
          volume24h: parseFloat(ticker.quote_volume_24h || '0'),
          high24h: parseFloat(ticker.high_24h || price),
          low24h: parseFloat(ticker.low_24h || price),
          lastUpdate: now,
          priceHistory: newHistory
        };

        this.assetData.set(symbol, assetData);
        this.emit('priceUpdate', assetData);
      }
    } catch (error) {
      logService.log('error', 'Failed to update asset data', error, 'BitmartService');
    }
  }

  async getBalance(type: 'spot' | 'margin' | 'futures' = 'spot'): Promise<BitmartBalance> {
    if (this.demoMode) {
      const baseAmount = type === 'spot' ? 50000 :
                        type === 'margin' ? 20000 :
                        30000;
      const variance = baseAmount * 0.2;
      const total = baseAmount + (Math.random() * variance);
      const frozen = total * (Math.random() * 0.2);

      return {
        total,
        available: total - frozen,
        frozen
      };
    }

    try {
      const timestamp = Date.now().toString();
      const sign = CryptoJS.HmacSHA256(
        `${timestamp}#${this.config?.memo}#balance`,
        this.config?.secret || ''
      ).toString();

      const endpoint = type === 'spot' ? '/spot/v1/wallet' :
                      type === 'margin' ? '/margin/v1/wallet' :
                      '/futures/v1/wallet';

      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        headers: {
          'X-BM-KEY': this.config?.apiKey || '',
          'X-BM-SIGN': sign,
          'X-BM-TIMESTAMP': timestamp,
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.code !== 1000) {
        throw new Error(data.message || 'Failed to fetch balance');
      }

      return {
        total: parseFloat(data.data.wallet.total),
        available: parseFloat(data.data.wallet.available),
        frozen: parseFloat(data.data.wallet.frozen)
      };
    } catch (error) {
      logService.log('error', `Failed to fetch ${type} balance`, error, 'BitmartService');
      throw error;
    }
  }

  subscribeToSymbol(symbol: string): void {
    if (!this.subscriptions.has(symbol)) {
      this.subscriptions.add(symbol);
      websocketService.subscribe(symbol, 'spot/ticker');
      this.updateAssetData(); // Get initial data
    }
  }

  unsubscribeFromSymbol(symbol: string): void {
    if (this.subscriptions.has(symbol)) {
      this.subscriptions.delete(symbol);
      websocketService.unsubscribe(symbol, 'spot/ticker');
    }
  }

  getAssetData(symbol: string): AssetData | undefined {
    return this.assetData.get(symbol);
  }

  getAllAssetData(): Map<string, AssetData> {
    return new Map(this.assetData);
  }

  async getTicker(symbol: string): Promise<BitmartTicker> {
    if (this.demoMode) {
      return this.generateDemoTicker(symbol);
    }

    try {
      const response = await fetch(`${this.baseUrl}/spot/v1/ticker?symbol=${symbol}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      if (data.code !== 1000) {
        throw new Error(data.message || `Failed to fetch ticker for ${symbol}`);
      }
      
      return data.data.tickers[0];
    } catch (error) {
      logService.log('error', `Failed to fetch ticker for ${symbol}`, error, 'BitmartService');
      return this.generateDemoTicker(symbol);
    }
  }

  private generateDemoTicker(symbol: string): BitmartTicker {
    const basePrice = symbol.includes('BTC') ? 45000 :
                     symbol.includes('ETH') ? 3000 :
                     symbol.includes('SOL') ? 100 :
                     symbol.includes('BNB') ? 300 :
                     symbol.includes('XRP') ? 0.5 : 1;

    const lastPrice = basePrice * (1 + (Math.random() - 0.5) * 0.002);
    const open24h = basePrice * (1 + (Math.random() - 0.5) * 0.01);
    const high24h = Math.max(lastPrice, open24h) * (1 + Math.random() * 0.005);
    const low24h = Math.min(lastPrice, open24h) * (1 - Math.random() * 0.005);

    return {
      symbol,
      last_price: lastPrice.toFixed(2),
      quote_volume_24h: (Math.random() * 1000000 + 500000).toFixed(2),
      base_volume_24h: (Math.random() * 100 + 50).toFixed(2),
      high_24h: high24h.toFixed(2),
      low_24h: low24h.toFixed(2),
      open_24h: open24h.toFixed(2),
      timestamp: Date.now()
    };
  }

  async getAllTickers(): Promise<BitmartTicker[]> {
    if (this.demoMode) {
      return this.DEFAULT_ASSETS.map(symbol => this.generateDemoTicker(symbol));
    }

    try {
      const response = await fetch(`${this.baseUrl}/spot/v1/ticker`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      if (data.code !== 1000) {
        throw new Error(data.message || 'Failed to fetch tickers');
      }
      
      return data.data.tickers;
    } catch (error) {
      logService.log('error', 'Failed to fetch all tickers', error, 'BitmartService');
      return this.DEFAULT_ASSETS.map(symbol => this.generateDemoTicker(symbol));
    }
  }

  isInitialized(): boolean {
    return this.initialized;
  }

  isDemo(): boolean {
    return this.demoMode;
  }

  isWebSocketConnected(): boolean {
    return websocketService.isConnected();
  }

  cleanup() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
    websocketService.disconnect();
    this.assetData.clear();
    this.subscriptions.clear();
    this.initialized = false;
  }
}

export const bitmartService = BitmartService.getInstance();