import { supabase } from './supabase';
import { AIService } from './ai-service';
import { logService } from './log-service';
import { tradeService } from './trade-service';
import { v4 as uuidv4 } from 'uuid';
import type { Database } from './supabase-types';
import type { RiskLevel } from './types';

type Strategy = Database['public']['Tables']['strategies']['Row'];
type StrategyTrade = Database['public']['Tables']['strategy_trades']['Row'];

// Demo strategies for fallback
const DEMO_STRATEGIES: Strategy[] = [
  {
    id: 'demo-strategy-1',
    title: 'Momentum Breakout Strategy',
    description: 'A momentum strategy that buys when price breaks above the 20-day moving average.',
    type: 'custom',
    status: 'active',
    performance: 15.7,
    risk_level: 'Medium',
    user_id: 'demo',
    strategy_config: {
      assets: ['BTC_USDT', 'ETH_USDT'],
      trade_parameters: {
        leverage: 2,
        position_size: 0.1
      },
      risk_management: {
        stop_loss: 2,
        take_profit: 6
      }
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

class StrategyService {
  private static instance: StrategyService;
  private retryCount = 0;
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000; // 1 second
  private demoMode = false;
  private strategyCache = new Map<string, Strategy>();
  private readonly DEFAULT_BUDGET = 100; // Default budget in USDT
  private readonly DEMO_USER_ID = 'demo';

  private constructor() {}

  static getInstance(): StrategyService {
    if (!StrategyService.instance) {
      StrategyService.instance = new StrategyService();
    }
    return StrategyService.instance;
  }

  private async retryOperation<T>(operation: () => Promise<T>): Promise<T> {
    try {
      return await operation();
    } catch (error) {
      if (this.retryCount < this.MAX_RETRIES) {
        this.retryCount++;
        await new Promise(resolve => setTimeout(resolve, this.RETRY_DELAY * this.retryCount));
        return this.retryOperation(operation);
      }
      throw error;
    }
  }

  private resetRetryCount() {
    this.retryCount = 0;
  }

  async getStrategies(): Promise<Strategy[]> {
    try {
      this.resetRetryCount();
      
      const { data, error } = await this.retryOperation(async () => 
        supabase
          .from('strategies')
          .select()
          .order('created_at', { ascending: false })
      );

      if (error) {
        this.demoMode = true;
        logService.log('warn', 'Failed to fetch strategies, falling back to demo mode', error, 'StrategyService');
        return DEMO_STRATEGIES;
      }

      const strategiesWithIds = (data || []).map(strategy => {
        const strategyWithId = {
          ...strategy,
          id: strategy.id || uuidv4()
        };
        this.strategyCache.set(strategyWithId.id, strategyWithId);
        return strategyWithId;
      });

      return strategiesWithIds;
    } catch (err) {
      this.demoMode = true;
      logService.log('warn', 'Error in getStrategies, falling back to demo mode', err, 'StrategyService');
      return DEMO_STRATEGIES;
    }
  }

  async getStrategy(id: string): Promise<Strategy | null> {
    try {
      // Check cache first
      if (this.strategyCache.has(id)) {
        return this.strategyCache.get(id) || null;
      }

      // Return demo strategy if in demo mode
      if (this.demoMode) {
        const demoStrategy = DEMO_STRATEGIES.find(s => s.id === id);
        if (demoStrategy) {
          this.strategyCache.set(id, demoStrategy);
        }
        return demoStrategy || null;
      }

      // Fetch from database
      const { data, error } = await supabase
        .from('strategies')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      // Handle 406 errors silently for non-existent strategies
      if (error?.code === 'PGRST116') {
        this.strategyCache.delete(id);
        return null;
      }

      if (error) {
        logService.log('error', `Error fetching strategy ${id}`, error, 'StrategyService');
        return this.strategyCache.get(id) || null;
      }

      if (data) {
        this.strategyCache.set(id, data);
        return data;
      }

      return null;
    } catch (err) {
      logService.log('error', `Error fetching strategy ${id}`, err, 'StrategyService');
      return this.strategyCache.get(id) || null;
    }
  }

  async createStrategy(data: {
    title: string;
    description: string | null;
    risk_level: RiskLevel;
    user_id: string;
  }): Promise<Strategy> {
    try {
      const strategyId = uuidv4();
      
      const strategyData = {
        ...data,
        id: strategyId,
        type: 'custom',
        status: 'inactive',
        performance: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const strategyConfig = await AIService.generateStrategy(
        data.description || data.title,
        data.risk_level
      );

      const { data: strategy, error } = await supabase
        .from('strategies')
        .insert({
          ...strategyData,
          strategy_config: strategyConfig
        })
        .select()
        .single();

      if (error) throw error;
      if (!strategy) throw new Error('Failed to create strategy');

      this.strategyCache.set(strategy.id, strategy);

      await tradeService.setBudget(strategy.id, {
        total: this.DEFAULT_BUDGET,
        allocated: 0,
        available: this.DEFAULT_BUDGET,
        maxPositionSize: this.DEFAULT_BUDGET * 0.1
      });

      logService.log('info', `Created strategy with default budget of ${this.DEFAULT_BUDGET} USDT`, { strategyId }, 'StrategyService');

      return strategy;
    } catch (err) {
      logService.log('error', 'Error creating strategy', err, 'StrategyService');
      throw err;
    }
  }

  async updateStrategy(id: string, updates: Partial<Strategy>): Promise<Strategy> {
    try {
      const existingStrategy = await this.getStrategy(id);
      if (!existingStrategy) {
        throw new Error('Strategy not found');
      }

      const { data: strategy, error } = await supabase
        .from('strategies')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select()
        .maybeSingle();

      // Handle 406 errors for non-existent strategies
      if (error?.code === 'PGRST116') {
        this.strategyCache.delete(id);
        logService.log('info', `Strategy ${id} not found during update, returning existing`, null, 'StrategyService');
        return existingStrategy;
      }

      if (error) throw error;
      if (!strategy) throw new Error('Strategy not found');

      this.strategyCache.set(id, strategy);

      logService.log('info', `Updated strategy ${id}`, strategy, 'StrategyService');
      return strategy;
    } catch (err) {
      logService.log('error', `Error updating strategy ${id}`, err, 'StrategyService');
      throw err;
    }
  }

  async deleteStrategy(id: string): Promise<void> {
    try {
      const existingStrategy = await this.getStrategy(id);
      if (!existingStrategy) {
        logService.log('info', `Strategy ${id} not found for deletion`, null, 'StrategyService');
        this.strategyCache.delete(id);
        return;
      }

      const { error } = await supabase
        .from('strategies')
        .delete()
        .eq('id', id);

      // Handle 406 errors silently for non-existent strategies
      if (error?.code === 'PGRST116') {
        this.strategyCache.delete(id);
        logService.log('info', `Strategy ${id} already deleted`, null, 'StrategyService');
        return;
      }

      if (error) throw error;

      this.strategyCache.delete(id);
      logService.log('info', `Deleted strategy ${id}`, null, 'StrategyService');
    } catch (err) {
      logService.log('error', `Failed to delete strategy ${id}`, err, 'StrategyService');
      throw err;
    }
  }

  async clearAllStrategies(): Promise<void> {
    try {
      const { error } = await supabase
        .from('strategies')
        .delete()
        .neq('id', '');

      if (error) throw error;

      this.strategyCache.clear();
      logService.log('info', 'Cleared all strategies', null, 'StrategyService');
    } catch (err) {
      logService.log('error', 'Error clearing all strategies', err, 'StrategyService');
      throw err;
    }
  }
}

export const strategyService = StrategyService.getInstance();

export { StrategyService };