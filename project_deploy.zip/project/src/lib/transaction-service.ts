import { supabase } from './supabase';
import { logService } from './log-service';
import { EventEmitter } from './event-emitter';
import { v4 as uuidv4 } from 'uuid';

export interface Transaction {
  id: string;
  user_id: string;
  strategy_id?: string;
  type: 'trade' | 'deposit' | 'withdrawal';
  amount: number;
  balance_before: number;
  balance_after: number;
  description?: string;
  status: 'pending' | 'completed' | 'failed';
  created_at: string;
  updated_at: string;
}

class TransactionService extends EventEmitter {
  private static instance: TransactionService;
  private transactions = new Map<string, Transaction[]>();
  private initialized = false;

  private constructor() {
    super();
  }

  static getInstance(): TransactionService {
    if (!TransactionService.instance) {
      TransactionService.instance = new TransactionService();
    }
    return TransactionService.instance;
  }

  async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      logService.log('info', 'Initializing transaction service', null, 'TransactionService');

      // Subscribe to realtime updates
      supabase
        .channel('transaction_changes')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'transaction_history' },
          this.handleRealtimeUpdate.bind(this)
        )
        .subscribe();

      this.initialized = true;
      logService.log('info', 'Transaction service initialized', null, 'TransactionService');
    } catch (error) {
      logService.log('error', 'Failed to initialize transaction service', error, 'TransactionService');
      throw error;
    }
  }

  private handleRealtimeUpdate(payload: any) {
    try {
      const userId = payload.new?.user_id;
      if (!userId) return;

      const userTransactions = this.transactions.get(userId) || [];

      switch (payload.eventType) {
        case 'INSERT':
          userTransactions.unshift(payload.new);
          break;
        case 'UPDATE':
          const index = userTransactions.findIndex(t => t.id === payload.new.id);
          if (index >= 0) {
            userTransactions[index] = payload.new;
          }
          break;
        case 'DELETE':
          const deleteIndex = userTransactions.findIndex(t => t.id === payload.old.id);
          if (deleteIndex >= 0) {
            userTransactions.splice(deleteIndex, 1);
          }
          break;
      }

      this.transactions.set(userId, userTransactions);
      this.emit('transactionsUpdated', { userId, transactions: userTransactions });
    } catch (error) {
      logService.log('error', 'Error handling realtime update', error, 'TransactionService');
    }
  }

  async recordTransaction(
    userId: string,
    type: Transaction['type'],
    amount: number,
    balanceBefore: number,
    description?: string,
    strategyId?: string
  ): Promise<Transaction> {
    try {
      const transaction: Partial<Transaction> = {
        id: uuidv4(),
        user_id: userId,
        strategy_id: strategyId,
        type,
        amount,
        balance_before: balanceBefore,
        balance_after: balanceBefore + amount,
        description,
        status: 'completed'
      };

      const { data, error } = await supabase
        .from('transaction_history')
        .insert(transaction)
        .select()
        .single();

      if (error) throw error;
      if (!data) throw new Error('Failed to create transaction');

      // Update local cache
      const userTransactions = this.transactions.get(userId) || [];
      userTransactions.unshift(data);
      this.transactions.set(userId, userTransactions);

      logService.log('info', `Recorded ${type} transaction for user ${userId}`, transaction, 'TransactionService');
      return data;
    } catch (error) {
      logService.log('error', 'Failed to record transaction', error, 'TransactionService');
      throw error;
    }
  }

  async getTransactionsForUser(userId: string): Promise<Transaction[]> {
    try {
      // Check cache first
      if (this.transactions.has(userId)) {
        return this.transactions.get(userId) || [];
      }

      const { data, error } = await supabase
        .from('transaction_history')
        .select()
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Update cache
      this.transactions.set(userId, data || []);
      return data || [];
    } catch (error) {
      logService.log('error', `Failed to get transactions for user ${userId}`, error, 'TransactionService');
      return [];
    }
  }

  async getTransactionsForStrategy(strategyId: string): Promise<Transaction[]> {
    try {
      const { data, error } = await supabase
        .from('transaction_history')
        .select()
        .eq('strategy_id', strategyId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      logService.log('error', `Failed to get transactions for strategy ${strategyId}`, error, 'TransactionService');
      return [];
    }
  }

  cleanup() {
    this.transactions.clear();
    this.initialized = false;
  }
}

export const transactionService = TransactionService.getInstance();