import { EventEmitter } from './event-emitter';
import { marketMonitor } from './market-monitor';
import { AIService } from './ai-service';
import { logService } from './log-service';
import { tradeService } from './trade-service';
import { analyticsService } from './analytics-service';
import { bitmartService } from './bitmart-service';
import type { Strategy } from './supabase-types';
import type { TradeConfig } from './types';

class TradeGenerator extends EventEmitter {
  private static instance: TradeGenerator;
  private activeStrategies: Map<string, Strategy> = new Map();
  private monitorState: Map<string, any> = new Map();
  private checkInterval: NodeJS.Timeout | null = null;
  private initialized = false;
  private readonly CHECK_FREQUENCY = 15000; // 15 seconds
  private readonly LOOKBACK_PERIOD = 60000; // 1 minute lookback for market data

  private constructor() {
    super();
  }

  static getInstance(): TradeGenerator {
    if (!TradeGenerator.instance) {
      TradeGenerator.instance = new TradeGenerator();
    }
    return TradeGenerator.instance;
  }

  async initialize(): Promise<void> {
    if (this.initialized) return;
    
    try {
      logService.log('info', 'Initializing trade generator', null, 'TradeGenerator');
      
      // Start periodic check for trading opportunities
      this.startPeriodicCheck();
      
      this.initialized = true;
      logService.log('info', 'Trade generator initialized', null, 'TradeGenerator');
    } catch (error) {
      logService.log('error', 'Failed to initialize trade generator', error, 'TradeGenerator');
      throw error;
    }
  }

  private startPeriodicCheck() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }

    this.checkInterval = setInterval(() => {
      this.checkTradingOpportunities();
    }, this.CHECK_FREQUENCY);
    
    logService.log('info', `Started checking for trading opportunities (every ${this.CHECK_FREQUENCY / 1000}s)`, null, 'TradeGenerator');
  }

  private async checkTradingOpportunities() {
    if (this.activeStrategies.size === 0) return;
    
    logService.log('debug', `Checking trading opportunities for ${this.activeStrategies.size} strategies`, null, 'TradeGenerator');
    
    for (const [strategyId, strategy] of this.activeStrategies.entries()) {
      try {
        const state = this.monitorState.get(strategyId);
        if (!state || !state.isActive) continue;
        
        // Skip if last check was too recent
        const now = Date.now();
        if (now - state.lastCheckTime < this.CHECK_FREQUENCY) continue;
        
        // Update last check time
        state.lastCheckTime = now;
        this.monitorState.set(strategyId, state);
        
        await this.checkStrategyForTrades(strategy);
      } catch (error) {
        logService.log('error', `Error checking trading opportunities for strategy ${strategyId}:`, error, 'TradeGenerator');
      }
    }
  }

  private async checkStrategyForTrades(strategy: Strategy) {
    if (!strategy.strategy_config?.assets) {
      logService.log('warn', `Strategy ${strategy.id} has no assets configured`, null, 'TradeGenerator');
      return;
    }
    
    try {
      logService.log('debug', `Checking trade opportunities for strategy ${strategy.id}`, null, 'TradeGenerator');
      
      // Retrieve budget and analytics data
      const budget = tradeService.getBudget(strategy.id);
      if (!budget || budget.available <= 0) {
        logService.log('debug', `No available budget for strategy ${strategy.id}`, null, 'TradeGenerator');
        return;
      }

      // Loop through each asset in the strategy
      for (const symbol of strategy.strategy_config.assets) {
        try {
          // Get historical data based on strategy timeframe
          const timeframe = strategy.strategy_config.conditions?.entry?.[0]?.timeframe || '1h';
          const historicalData = await this.getHistoricalData(symbol, timeframe);
          
          if (!historicalData || historicalData.length === 0) {
            logService.log('warn', `No historical data available for ${symbol}`, null, 'TradeGenerator');
            continue;
          }

          // Get current market data
          const ticker = await bitmartService.getTicker(symbol);
          const currentPrice = parseFloat(ticker.last_price);
          
          // Get market state and indicators
          const marketState = marketMonitor.getMarketState(symbol);
          if (!marketState) {
            logService.log('debug', `No market state for ${symbol}`, null, 'TradeGenerator');
            continue;
          }

          // Get indicator values based on strategy configuration
          const indicators = await marketMonitor.getIndicatorValues(
            symbol,
            strategy.strategy_config.indicators || []
          );

          // Check entry conditions
          const shouldEnter = await this.checkEntryConditions(
            strategy,
            indicators,
            historicalData,
            currentPrice
          );

          if (shouldEnter) {
            // Use AI to validate trade opportunity
            const tradeSignal = await this.generateTradeSignal(
              strategy,
              symbol,
              indicators,
              historicalData,
              marketState
            );

            if (tradeSignal && tradeSignal.confidence >= (strategy.strategy_config.trade_parameters?.confidence_factor || 0.7)) {
              // Calculate position size based on risk level and available budget
              const positionSize = this.calculatePositionSize(
                strategy,
                budget.available,
                currentPrice,
                tradeSignal.confidence
              );

              // Generate trade config
              const tradeConfig: TradeConfig = {
                symbol,
                type: tradeSignal.direction,
                amount: positionSize,
                leverage: strategy.strategy_config.trade_parameters?.leverage || 1,
                stopLoss: strategy.strategy_config.risk_management?.stop_loss || 2,
                takeProfit: strategy.strategy_config.risk_management?.take_profit || 6,
                trailingStop: strategy.strategy_config.risk_management?.trailing_stop_loss
              };

              // Emit trade opportunity
              this.emit('tradeOpportunity', { 
                strategy, 
                config: tradeConfig,
                rationale: tradeSignal.rationale
              });
              
              logService.log('info', `Trade opportunity found for ${symbol}`, {
                config: tradeConfig,
                rationale: tradeSignal.rationale
              }, 'TradeGenerator');
            }
          }
        } catch (error) {
          logService.log('error', `Error processing asset ${symbol}`, error, 'TradeGenerator');
        }
      }
    } catch (error) {
      logService.log('error', `Error checking strategy ${strategy.id} for trades`, error, 'TradeGenerator');
    }
  }

  private async getHistoricalData(symbol: string, timeframe: string): Promise<any[]> {
    try {
      // Convert timeframe to milliseconds
      const timeframeMs = this.convertTimeframeToMs(timeframe);
      const endTime = Math.floor(Date.now() / 1000);
      const startTime = Math.floor((Date.now() - (timeframeMs * 100)) / 1000); // Get 100 candles

      const klines = await bitmartService.getKlines(symbol, startTime, endTime, timeframe);
      return klines.map(kline => ({
        timestamp: kline[0],
        open: parseFloat(kline[1]),
        high: parseFloat(kline[2]),
        low: parseFloat(kline[3]),
        close: parseFloat(kline[4]),
        volume: parseFloat(kline[5])
      }));
    } catch (error) {
      logService.log('error', `Failed to get historical data for ${symbol}`, error, 'TradeGenerator');
      return [];
    }
  }

  private convertTimeframeToMs(timeframe: string): number {
    const unit = timeframe.slice(-1);
    const value = parseInt(timeframe.slice(0, -1));
    
    switch (unit) {
      case 'm': return value * 60 * 1000;
      case 'h': return value * 60 * 60 * 1000;
      case 'd': return value * 24 * 60 * 60 * 1000;
      default: return 60 * 60 * 1000; // Default to 1h
    }
  }

  private async checkEntryConditions(
    strategy: Strategy,
    indicators: any[],
    historicalData: any[],
    currentPrice: number
  ): Promise<boolean> {
    try {
      if (!strategy.strategy_config?.conditions?.entry) {
        return false;
      }

      // Check each entry condition
      return strategy.strategy_config.conditions.entry.every(condition => {
        const indicator = indicators.find(i => i.name.toLowerCase() === condition.indicator.toLowerCase());
        if (!indicator) return false;

        const value = indicator.value;
        const threshold = condition.value;

        switch (condition.operator) {
          case '>': return value > threshold;
          case '<': return value < threshold;
          case '>=': return value >= threshold;
          case '<=': return value <= threshold;
          case '==': return value === threshold;
          case 'crosses_above': {
            const prevValue = this.getPreviousIndicatorValue(
              condition.indicator,
              historicalData,
              condition.timeframe
            );
            return prevValue <= threshold && value > threshold;
          }
          case 'crosses_below': {
            const prevValue = this.getPreviousIndicatorValue(
              condition.indicator,
              historicalData,
              condition.timeframe
            );
            return prevValue >= threshold && value < threshold;
          }
          default: return false;
        }
      });
    } catch (error) {
      logService.log('error', 'Error checking entry conditions', error, 'TradeGenerator');
      return false;
    }
  }

  private getPreviousIndicatorValue(
    indicatorName: string,
    historicalData: any[],
    timeframe: string
  ): number {
    try {
      // Get previous candle based on timeframe
      const prevCandle = historicalData[historicalData.length - 2];
      if (!prevCandle) return 0;

      // Calculate indicator value for previous candle
      switch (indicatorName.toLowerCase()) {
        case 'rsi': {
          const prices = historicalData.map(d => d.close);
          const rsi = RSI.calculate({ values: prices, period: 14 });
          return rsi[rsi.length - 2] || 0;
        }
        case 'macd': {
          const prices = historicalData.map(d => d.close);
          const macd = MACD.calculate({
            values: prices,
            fastPeriod: 12,
            slowPeriod: 26,
            signalPeriod: 9
          });
          return macd[macd.length - 2]?.MACD || 0;
        }
        default:
          return prevCandle.close;
      }
    } catch (error) {
      logService.log('error', 'Error getting previous indicator value', error, 'TradeGenerator');
      return 0;
    }
  }

  private async generateTradeSignal(
    strategy: Strategy,
    symbol: string,
    indicators: any[],
    historicalData: any[],
    marketState: any
  ): Promise<{ direction: 'Long' | 'Short'; confidence: number; rationale: string } | null> {
    try {
      // Prepare data for DeepSeek
      const prompt = `Analyze this trading opportunity:

Strategy: ${strategy.title}
Symbol: ${symbol}
Market State: ${JSON.stringify(marketState)}
Indicators: ${JSON.stringify(indicators)}
Risk Level: ${strategy.risk_level}

Strategy Configuration:
${JSON.stringify(strategy.strategy_config, null, 2)}

Recent Price Action:
${JSON.stringify(historicalData.slice(-5), null, 2)}

Generate a trade signal with:
1. Direction (Long/Short)
2. Confidence score (0-1)
3. Detailed rationale for the trade

Return ONLY a JSON object with this structure:
{
  "direction": "Long" | "Short",
  "confidence": number,
  "rationale": string
}`;

      const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_DEEPSEEK_API_KEY}`
        },
        body: JSON.stringify({
          model: 'deepseek-chat',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.3,
          max_tokens: 500
        })
      });

      if (!response.ok) {
        throw new Error(`DeepSeek API error: ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;

      if (!content) {
        throw new Error('Empty response from DeepSeek');
      }

      // Extract JSON from response
      const jsonStart = content.indexOf('{');
      const jsonEnd = content.lastIndexOf('}');
      
      if (jsonStart === -1 || jsonEnd === -1) {
        throw new Error('No valid JSON found in response');
      }

      const signal = JSON.parse(content.substring(jsonStart, jsonEnd + 1));

      // Validate signal
      if (!signal.direction || !signal.confidence || !signal.rationale) {
        throw new Error('Invalid trade signal format');
      }

      return signal;
    } catch (error) {
      logService.log('error', 'Failed to generate trade signal', error, 'TradeGenerator');
      return null;
    }
  }

  private calculatePositionSize(
    strategy: Strategy,
    availableBudget: number,
    currentPrice: number,
    confidence: number
  ): number {
    const riskMultiplier = {
      'Ultra Low': 0.05,
      'Low': 0.1,
      'Medium': 0.15,
      'High': 0.2,
      'Ultra High': 0.25,
      'Extreme': 0.3,
      'God Mode': 0.5
    }[strategy.risk_level] || 0.15;

    // Base position size on risk level and confidence
    const baseSize = availableBudget * riskMultiplier;
    const confidenceAdjustedSize = baseSize * confidence;

    // Ensure position size doesn't exceed max allowed
    const maxPositionSize = strategy.strategy_config?.trade_parameters?.position_size || 0.1;
    const finalSize = Math.min(confidenceAdjustedSize, availableBudget * maxPositionSize);

    // Round to 8 decimal places for crypto
    return Math.floor(finalSize * 1e8) / 1e8;
  }

  async addStrategy(strategy: Strategy): Promise<void> {
    try {
      if (!this.initialized) {
        await this.initialize();
      }
      
      if (!strategy.strategy_config?.assets) {
        throw new Error('Strategy has no assets configured');
      }
      
      logService.log('info', `Adding strategy ${strategy.id} to trade generator`, null, 'TradeGenerator');
      
      // Add to active strategies and initialize monitoring state
      this.activeStrategies.set(strategy.id, strategy);
      this.monitorState.set(strategy.id, {
        isActive: true,
        lastCheckTime: Date.now() - this.CHECK_FREQUENCY // Allow immediate check
      });
      
      // Subscribe to market data for each asset
      for (const symbol of strategy.strategy_config.assets) {
        bitmartService.subscribeToSymbol(symbol);
        await marketMonitor.addAsset(symbol);
      }
      
      logService.log('info', `Strategy ${strategy.id} added to trade generator`, null, 'TradeGenerator');
    } catch (error) {
      logService.log('error', `Failed to add strategy ${strategy.id} to trade generator`, error, 'TradeGenerator');
      throw error;
    }
  }

  removeStrategy(strategyId: string): void {
    try {
      const strategy = this.activeStrategies.get(strategyId);
      if (!strategy) return;

      // Remove strategy from active lists
      this.activeStrategies.delete(strategyId);
      this.monitorState.delete(strategyId);

      // Unsubscribe from market data if no other strategy uses the asset
      if (strategy.strategy_config?.assets) {
        for (const asset of strategy.strategy_config.assets) {
          const isUsedByOtherStrategy = Array.from(this.activeStrategies.values())
            .some(s => s.strategy_config?.assets?.includes(asset));
          if (!isUsedByOtherStrategy) {
            bitmartService.unsubscribeFromSymbol(asset);
            marketMonitor.removeAsset(asset);
          }
        }
      }

      logService.log('info', `Strategy ${strategyId} removed from trade generator`, null, 'TradeGenerator');
    } catch (error) {
      logService.log('error', `Error removing strategy ${strategyId}`, error, 'TradeGenerator');
    }
  }

  getActiveStrategies(): Strategy[] {
    return Array.from(this.activeStrategies.values());
  }

  isMonitoringStrategy(strategyId: string): boolean {
    const state = this.monitorState.get(strategyId);
    return !!state && state.isActive;
  }

  pauseStrategy(strategyId: string): void {
    const state = this.monitorState.get(strategyId);
    if (state) {
      state.isActive = false;
      this.monitorState.set(strategyId, state);
      logService.log('info', `Paused monitoring for strategy ${strategyId}`, null, 'TradeGenerator');
    }
  }

  resumeStrategy(strategyId: string): void {
    const state = this.monitorState.get(strategyId);
    if (state) {
      state.isActive = true;
      state.lastCheckTime = Date.now() - this.CHECK_FREQUENCY; // Allow immediate check
      this.monitorState.set(strategyId, state);
      logService.log('info', `Resumed monitoring for strategy ${strategyId}`, null, 'TradeGenerator');
    }
  }

  cleanup() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    this.activeStrategies.clear();
    this.monitorState.clear();
    this.initialized = false;
    logService.log('info', 'Trade generator cleaned up', null, 'TradeGenerator');
  }
}

export const tradeGenerator = TradeGenerator.getInstance();