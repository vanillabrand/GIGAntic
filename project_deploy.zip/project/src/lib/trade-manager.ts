import { EventEmitter } from './event-emitter';
import { supabase } from './supabase';
import { exchangeService } from './exchange-service';
import { tradeGenerator } from './trade-generator';
import { logService } from './log-service';
import { v4 as uuidv4 } from 'uuid';
import type { Strategy, StrategyTrade } from './supabase-types';
import type { TradeConfig } from './types';

class TradeManager extends EventEmitter {
  private static instance: TradeManager;
  // Map of strategyId to a map of tradeId -> trade
  private activeTrades: Map<string, Map<string, StrategyTrade>> = new Map();
  private updateInterval: NodeJS.Timeout | null = null;
  private initialized = false;
  private isUpdating = false;
  private readonly UPDATE_INTERVAL = 15000; // 15 seconds

  private constructor() {
    super();
    this.setupEventListeners();
  }

  static getInstance(): TradeManager {
    if (!TradeManager.instance) {
      TradeManager.instance = new TradeManager();
    }
    return TradeManager.instance;
  }

  private setupEventListeners() {
    // Listen to trade opportunities from the TradeGenerator.
    tradeGenerator.on('tradeOpportunity', async ({ strategy, config }) => {
      await this.executeTrade(strategy, config);
    });
  }

  async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      logService.log('info', 'Initializing trade manager', null, 'TradeManager');
      
      // Load active trades from the database.
      const { data: trades, error } = await supabase
        .from('strategy_trades')
        .select('*')
        .eq('status', 'open');

      if (error) throw error;

      if (trades) {
        trades.forEach(trade => {
          if (!this.activeTrades.has(trade.strategy_id)) {
            this.activeTrades.set(trade.strategy_id, new Map());
          }
          this.activeTrades.get(trade.strategy_id)?.set(trade.id, trade);
        });
        logService.log('info', `Loaded ${trades.length} active trades`, null, 'TradeManager');
      }

      // Start periodic updates.
      this.startUpdateInterval();

      this.initialized = true;
      logService.log('info', 'Trade manager initialized successfully', null, 'TradeManager');
    } catch (error) {
      logService.log('error', 'Failed to initialize trade manager', error, 'TradeManager');
      throw error;
    }
  }

  private startUpdateInterval() {
    if (this.updateInterval) return;

    this.updateInterval = setInterval(() => {
      this.updateActiveTrades();
    }, this.UPDATE_INTERVAL);
    
    logService.log('info', 'Started trade update interval', null, 'TradeManager');
  }

  // Iterates through all active trades and updates them based on current market data.
  private async updateActiveTrades() {
    if (this.isUpdating || this.activeTrades.size === 0) return;
    
    this.isUpdating = true;
    
    try {
      for (const [strategyId, trades] of this.activeTrades.entries()) {
        for (const trade of trades.values()) {
          try {
            const ticker = await exchangeService.fetchTicker(trade.pair);
            const currentPrice = parseFloat(ticker.last_price);
            
            // Calculate profit/loss and percentage.
            const pnl = trade.type === 'Long' 
              ? (currentPrice - trade.entry_price) * trade.amount
              : (trade.entry_price - currentPrice) * trade.amount;
            const pnlPercent = (pnl / (trade.entry_price * trade.amount)) * 100;

            // Calculate trade duration.
            const startDate = new Date(trade.created_at);
            const now = new Date();
            const durationMs = now.getTime() - startDate.getTime();
            const hours = Math.floor(durationMs / (1000 * 60 * 60));
            const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
            const duration = `${hours}h ${minutes}m`;

            // Update trade record in the database.
            const { data: updatedTrade, error } = await supabase
              .from('strategy_trades')
              .update({
                current_price: currentPrice,
                pnl,
                pnl_percent: pnlPercent,
                duration,
                updated_at: new Date().toISOString()
              })
              .eq('id', trade.id)
              .select()
              .single();

            if (error) {
              throw error;
            }

            if (updatedTrade) {
              // Update local cache.
              trades.set(updatedTrade.id, updatedTrade);
              
              // Emit an event for the updated trade.
              this.emit('tradeExecuted', { 
                type: 'update', 
                trade: updatedTrade 
              });
            }
          } catch (error) {
            logService.log('warn', `Error updating trade ${trade.id}`, error, 'TradeManager');
          }
        }
      }
    } catch (error) {
      logService.log('error', 'Error in updateActiveTrades', error, 'TradeManager');
    } finally {
      this.isUpdating = false;
    }
  }

  // Executes a trade for a given strategy based on the provided configuration.
  async executeTrade(strategy: Strategy, config: TradeConfig) {
    if (!this.initialized) {
      await this.initialize();
    }

    try {
      logService.log('info', `Executing trade for strategy ${strategy.id}`, config, 'TradeManager');
      
      // Get current market price.
      const ticker = await exchangeService.fetchTicker(config.symbol);
      const currentPrice = parseFloat(ticker.last_price);
      
      // Create a new trade record in the database.
      const { data: trade, error } = await supabase
        .from('strategy_trades')
        .insert({
          id: uuidv4(),
          strategy_id: strategy.id,
          pair: config.symbol,
          type: config.type,
          entry_price: currentPrice,
          current_price: currentPrice,
          amount: config.amount,
          pnl: 0,
          pnl_percent: 0,
          status: 'open'
        })
        .select()
        .single();

      if (error || !trade) {
        throw error || new Error('Failed to create trade record');
      }

      // If live mode is enabled, execute the order on the exchange.
      if (exchangeService.isLive()) {
        try {
          await exchangeService.createOrder(
            config.symbol,
            'market',
            config.type === 'Long' ? 'buy' : 'sell',
            config.amount,
            currentPrice
          );
        } catch (orderError) {
          logService.log('error', 'Failed to execute order on exchange', orderError, 'TradeManager');
          // Continue processing since the trade record exists.
        }
      }
      
      // Add the trade to the active trades collection.
      if (!this.activeTrades.has(strategy.id)) {
        this.activeTrades.set(strategy.id, new Map());
      }
      this.activeTrades.get(strategy.id)?.set(trade.id, trade);
      
      // Emit a trade executed event.
      this.emit('tradeExecuted', { 
        type: 'open', 
        trade 
      });
      
      return trade;
    } catch (error) {
      logService.log('error', `Failed to execute trade for strategy ${strategy.id}`, error, 'TradeManager');
      throw error;
    }
  }

  // Closes a trade by updating its status to 'closed' and removing it from local state.
  async closeTrade(tradeId: string): Promise<void> {
    try {
      let foundTrade: StrategyTrade | undefined;
      let strategyId: string | undefined;

      // Search for the trade in the nested active trades map.
      for (const [sId, trades] of this.activeTrades.entries()) {
        if (trades.has(tradeId)) {
          foundTrade = trades.get(tradeId);
          strategyId = sId;
          break;
        }
      }

      if (!foundTrade || !strategyId) {
        throw new Error(`Trade ${tradeId} not found`);
      }

      // Update the trade record in the database to mark it as closed.
      const { data: updatedTrade, error } = await supabase
        .from('strategy_trades')
        .update({
          status: 'closed',
          updated_at: new Date().toISOString()
        })
        .eq('id', tradeId)
        .select()
        .single();

      if (error) throw error;

      if (updatedTrade) {
        // Remove the trade from the active trades cache.
        this.activeTrades.get(strategyId)?.delete(tradeId);
        if (this.activeTrades.get(strategyId)?.size === 0) {
          this.activeTrades.delete(strategyId);
        }
        
        // Emit an event indicating that the trade has been closed.
        this.emit('tradeExecuted', { 
          type: 'close', 
          trade: updatedTrade 
        });
        
        logService.log('info', `Closed trade ${tradeId} with P&L ${updatedTrade.pnl.toFixed(2)}`, updatedTrade, 'TradeManager');
      }
    } catch (error) {
      logService.log('error', `Failed to close trade ${tradeId}`, error, 'TradeManager');
      throw error;
    }
  }

  // Loads existing active trades for a given strategy into the local cache.
  async initializeStrategy(strategy: Strategy): Promise<void> {
    try {
      logService.log('info', `Initializing trade manager for strategy ${strategy.id}`, null, 'TradeManager');
      
      if (!this.initialized) {
        await this.initialize();
      }
      
      const { data: trades, error } = await supabase
        .from('strategy_trades')
        .select('*')
        .eq('strategy_id', strategy.id)
        .eq('status', 'open');

      if (error) throw error;

      if (trades) {
        if (!this.activeTrades.has(strategy.id)) {
          this.activeTrades.set(strategy.id, new Map());
        }
        
        trades.forEach(trade => {
          this.activeTrades.get(strategy.id)?.set(trade.id, trade);
        });
        
        logService.log('info', `Loaded ${trades.length} active trades for strategy ${strategy.id}`, null, 'TradeManager');
      }
    } catch (error) {
      logService.log('error', `Failed to initialize trade manager for strategy ${strategy.id}`, error, 'TradeManager');
      throw error;
    }
  }

  // Returns active trades for a given strategy.
  getActiveTradesForStrategy(strategyId: string): StrategyTrade[] {
    const strategyTrades = this.activeTrades.get(strategyId);
    return strategyTrades ? Array.from(strategyTrades.values()) : [];
  }

  // Returns active trades grouped by strategy.
  getActiveTradesGroupedByStrategy(): Map<string, StrategyTrade[]> {
    const groupedTrades = new Map<string, StrategyTrade[]>();
    this.activeTrades.forEach((trades, strategyId) => {
      groupedTrades.set(strategyId, Array.from(trades.values()));
    });
    return groupedTrades;
  }

  isInitialized(): boolean {
    return this.initialized;
  }

  cleanup() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
    this.activeTrades.clear();
    this.initialized = false;
    this.isUpdating = false;
  }
}

export const tradeManager = TradeManager.getInstance();
