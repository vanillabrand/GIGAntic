import { backOff } from 'exponential-backoff';
import axios from 'axios';
import { tradeService } from './trade-service';
import { aiTradeService } from './ai-trade-service';
import { logService } from './log-service';
import { EventEmitter } from './event-emitter';
import type { Strategy } from './supabase-types';
import { SMA, RSI, MACD, BollingerBands, ATR } from 'technicalindicators';

class AIService extends EventEmitter {
  private static instance: AIService;
  private static DEEPSEEK_API_KEY = import.meta.env.VITE_DEEPSEEK_API_KEY;
  private static DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions';
  private retryCount = 0;
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000;
  private readonly TIMEOUT = 10000; // 10 seconds

  private constructor() {
    super();
  }

  static getInstance(): AIService {
    if (!AIService.instance) {
      AIService.instance = new AIService();
    }
    return AIService.instance;
  }

  static async generateStrategy(description: string, riskLevel: string): Promise<any> {
    return AIService.getInstance().generateStrategy(description, riskLevel);
  }

  async generateStrategy(description: string, riskLevel: string): Promise<any> {
    if (!description) {
      throw new Error('Strategy description is required');
    }

    if (!riskLevel) {
      throw new Error('Risk level is required');
    }

    try {
      this.emit('progress', { step: 'Analyzing strategy description...', progress: 10 });
      
      // Extract trading pairs from description
      const assets = this.extractAssetPairs(description);
      
      this.emit('progress', { step: 'Detected trading pairs: ' + assets.join(', '), progress: 20 });

      // Try AI-powered strategy generation with retries and timeout
      const strategy = await Promise.race([
        this.generateWithDeepSeek(description, riskLevel, assets),
        new Promise((_, reject) => 
          setTimeout(() => {
            this.emit('progress', { step: 'Strategy generation timeout, falling back...', progress: 0 });
            reject(new Error('Strategy generation timeout'));
          }, this.TIMEOUT)
        )
      ]);

      // Show the generated strategy in a code block
      this.emit('result', { strategy: JSON.stringify(strategy, null, 2) });

      return strategy;
    } catch (error) {
      logService.log('warn', 'AI strategy generation failed, falling back to rule-based:', error, 'AIService');
      this.emit('progress', { step: 'Generating rule-based strategy...', progress: 50 });
      const strategy = this.generateRuleBasedStrategy(description, riskLevel);
      this.emit('progress', { step: 'Strategy generated successfully!', progress: 100 });
      this.emit('result', { strategy: JSON.stringify(strategy, null, 2) });
      return strategy;
    }
  }

  private extractAssetPairs(description: string): string[] {
    const pairs = new Set<string>();
    
    // Check for "top N" pattern
    const topNMatch = description.match(/top\s+(\d+)/i);
    if (topNMatch) {
      const n = parseInt(topNMatch[1]);
      const topPairs = ['BTC_USDT', 'ETH_USDT', 'SOL_USDT', 'BNB_USDT', 'XRP_USDT']
        .slice(0, Math.min(n, 5));
      topPairs.forEach(pair => pairs.add(pair));
      return Array.from(pairs);
    }

    // Check for strategy type hints
    const isArbitrage = /arbitrage/i.test(description);
    const isScalping = /scalp/i.test(description);
    const isMomentum = /momentum/i.test(description);

    if (isArbitrage) {
      pairs.add('BTC_USDT');
      pairs.add('ETH_USDT');
      pairs.add('SOL_USDT');
    } else if (isScalping) {
      pairs.add('SOL_USDT');
      pairs.add('MATIC_USDT');
    } else if (isMomentum) {
      pairs.add('BTC_USDT');
      pairs.add('ETH_USDT');
    }

    // Extract explicit pairs
    const pairFormats = [
      /\b(BTC|ETH|SOL|BNB|XRP|ADA|DOGE|MATIC|DOT|LINK)[-/]?(USDT)\b/gi,
      /\b(Bitcoin|Ethereum|Solana|Binance|Ripple|Cardano|Dogecoin|Polygon|Polkadot|Chainlink)\b/gi
    ];

    const nameToSymbol: { [key: string]: string } = {
      'bitcoin': 'BTC',
      'ethereum': 'ETH',
      'solana': 'SOL',
      'binance': 'BNB',
      'ripple': 'XRP',
      'cardano': 'ADA',
      'dogecoin': 'DOGE',
      'polygon': 'MATIC',
      'polkadot': 'DOT',
      'chainlink': 'LINK'
    };

    pairFormats.forEach(format => {
      const matches = description.match(format);
      if (matches) {
        matches.forEach(match => {
          const upperMatch = match.toUpperCase();
          if (upperMatch.includes('USDT')) {
            const symbol = upperMatch.replace(/[-/]?USDT$/, '');
            pairs.add(`${symbol}_USDT`);
          } else {
            const symbol = nameToSymbol[match.toLowerCase()];
            if (symbol) {
              pairs.add(`${symbol}_USDT`);
            }
          }
        });
      }
    });

    // If no pairs found, return default based on risk level
    if (pairs.size === 0) {
      pairs.add('BTC_USDT');
      pairs.add('ETH_USDT');
    }

    return Array.from(pairs);
  }

  private async generateWithDeepSeek(description: string, riskLevel: string, assets: string[]): Promise<any> {
    try {
      // If no API key, fall back to rule-based immediately
      if (!AIService.DEEPSEEK_API_KEY || AIService.DEEPSEEK_API_KEY === 'your_api_key') {
        throw new Error('No valid DeepSeek API key');
      }

      this.emit('progress', { step: 'Preparing strategy parameters...', progress: 30 });

      const prompt = `Generate a detailed cryptocurrency trading strategy based on the following:

Description: "${description}"
Risk Level: ${riskLevel}
Detected Assets: ${assets.join(', ')}

Requirements:
1. Use the exact trading pairs provided: ${assets.join(', ')}
2. Include specific entry and exit conditions with clear numeric values
3. Include risk management parameters appropriate for ${riskLevel} risk level
4. Specify position sizing and leverage limits
5. Include required technical indicators with exact parameters
6. MUST include a detailed strategy rationale explaining the strategy's approach and methodology

Format the response as a JSON object with this structure:
{
  "strategy_name": string,
  "strategy_rationale": string (REQUIRED - detailed explanation of strategy approach),
  "market_type": "spot" | "futures",
  "assets": ${JSON.stringify(assets)},
  "trade_parameters": {
    "leverage": number,
    "position_size": number (0-1),
    "confidence_factor": number (0-1)
  },
  "conditions": {
    "entry": [
      {
        "indicator": string,
        "operator": ">" | "<" | ">=" | "<=" | "==" | "crosses_above" | "crosses_below",
        "value": number,
        "timeframe": string
      }
    ],
    "exit": [
      {
        "indicator": string,
        "operator": string,
        "value": number,
        "timeframe": string
      }
    ]
  },
  "risk_management": {
    "stop_loss": number,
    "take_profit": number,
    "trailing_stop_loss": number,
    "max_drawdown": number
  },
  "indicators": [
    {
      "name": string,
      "parameters": object,
      "weight": number
    }
  ]
}

IMPORTANT:
- Entry/exit conditions must be specific and numeric
- Risk parameters must match the ${riskLevel} risk level
- Position size must be appropriate for the risk level
- Include detailed indicator configurations
- Ensure all numeric values are reasonable and properly scaled
- MUST include a detailed strategy_rationale field explaining the strategy's approach`;

      this.emit('progress', { step: 'Sending request to DeepSeek API...', progress: 40 });

      const response = await fetch(AIService.DEEPSEEK_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AIService.DEEPSEEK_API_KEY}`
        },
        body: JSON.stringify({
          model: 'deepseek-chat',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7,
          max_tokens: 1000
        })
      });

      if (!response.ok) {
        throw new Error(`DeepSeek API error: ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;

      if (!content) {
        throw new Error('Empty response from DeepSeek');
      }

      // Extract JSON from response
      const jsonStart = content.indexOf('{');
      const jsonEnd = content.lastIndexOf('}');
      
      if (jsonStart === -1 || jsonEnd === -1) {
        throw new Error('No valid JSON found in response');
      }

      const jsonContent = content.substring(jsonStart, jsonEnd + 1);
      const strategy = JSON.parse(jsonContent);

      // Ensure strategy_rationale exists
      if (!strategy.strategy_rationale) {
        throw new Error('Strategy rationale is required but was not provided');
      }

      return this.normalizeStrategyConfig(strategy, riskLevel);
    } catch (error) {
      logService.log('error', 'DeepSeek API call failed:', error, 'AIService');
      throw error;
    }
  }

  private generateRuleBasedStrategy(description: string, riskLevel: string): any {
    const assets = this.extractAssetPairs(description);
    const isHighRisk = riskLevel === 'High' || riskLevel === 'Ultra High' || riskLevel === 'Extreme' || riskLevel === 'God Mode';
    const isMediumRisk = riskLevel === 'Medium';

    return {
      strategy_name: "Rule-Based Strategy",
      strategy_rationale: `This ${riskLevel.toLowerCase()} risk strategy combines RSI and MACD indicators to identify potential entry and exit points. The strategy ${isHighRisk ? 'aggressively' : isMediumRisk ? 'moderately' : 'conservatively'} trades on momentum shifts while maintaining strict risk management parameters. ${description}`,
      market_type: isHighRisk ? "futures" : "spot",
      assets,
      trade_parameters: {
        leverage: isHighRisk ? 5 : isMediumRisk ? 2 : 1,
        position_size: isHighRisk ? 0.2 : isMediumRisk ? 0.1 : 0.05,
        confidence_factor: 0.7
      },
      conditions: {
        entry: [
          {
            indicator: "RSI",
            operator: "<",
            value: 30,
            timeframe: "1h"
          },
          {
            indicator: "MACD",
            operator: "crosses_above",
            value: 0,
            timeframe: "1h"
          }
        ],
        exit: [
          {
            indicator: "RSI",
            operator: ">",
            value: 70,
            timeframe: "1h"
          },
          {
            indicator: "MACD",
            operator: "crosses_below",
            value: 0,
            timeframe: "1h"
          }
        ]
      },
      risk_management: {
        stop_loss: isHighRisk ? 5 : isMediumRisk ? 3 : 2,
        take_profit: isHighRisk ? 15 : isMediumRisk ? 9 : 6,
        trailing_stop_loss: isHighRisk ? 3 : isMediumRisk ? 2 : 1,
        max_drawdown: isHighRisk ? 25 : isMediumRisk ? 15 : 10
      },
      indicators: [
        {
          name: "RSI",
          parameters: { period: 14 },
          weight: 1
        },
        {
          name: "MACD",
          parameters: {
            fastPeriod: 12,
            slowPeriod: 26,
            signalPeriod: 9
          },
          weight: 1
        }
      ]
    };
  }

  private normalizeStrategyConfig(strategyConfig: any, riskLevel: string): any {
    // Normalize risk parameters based on risk level
    const riskMultiplier = riskLevel === 'High' ? 2 : riskLevel === 'Medium' ? 1.5 : 1;

    // Ensure strategy_rationale exists and is meaningful
    if (!strategyConfig.strategy_rationale || strategyConfig.strategy_rationale.length < 50) {
      strategyConfig.strategy_rationale = `This ${riskLevel.toLowerCase()} risk strategy is designed to ${
        strategyConfig.market_type === 'futures' ? 'trade futures contracts' : 'spot trade'
      } on ${strategyConfig.assets.join(', ')}. It utilizes ${
        strategyConfig.indicators.map((i: any) => i.name).join(', ')
      } for signal generation with appropriate risk management parameters for the ${riskLevel.toLowerCase()} risk profile.`;
    }

    // Ensure trade parameters are within acceptable ranges
    strategyConfig.trade_parameters = {
      ...strategyConfig.trade_parameters,
      leverage: Math.min(strategyConfig.trade_parameters?.leverage || 1, riskLevel === 'High' ? 5 : 2),
      position_size: Math.min(strategyConfig.trade_parameters?.position_size || 0.1, riskLevel === 'High' ? 0.15 : 0.1),
      confidence_factor: Math.min(strategyConfig.trade_parameters?.confidence_factor || 0.7, 0.9)
    };

    // Normalize risk management parameters
    strategyConfig.risk_management = {
      ...strategyConfig.risk_management,
      stop_loss: Math.min(strategyConfig.risk_management?.stop_loss || 2, 5 * riskMultiplier),
      take_profit: Math.min(strategyConfig.risk_management?.take_profit || 6, 15 * riskMultiplier),
      trailing_stop_loss: Math.min(strategyConfig.risk_management?.trailing_stop_loss || 1, 3 * riskMultiplier),
      max_drawdown: Math.min(strategyConfig.risk_management?.max_drawdown || 15, 30 * riskMultiplier)
    };

    return strategyConfig;
  }
}

export const aiService = AIService.getInstance();
export { AIService };