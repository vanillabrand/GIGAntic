import { EventEmitter } from './event-emitter';
import { logService } from './log-service';

export interface NewsItem {
  id: string;
  title: string;
  description: string;
  url: string;
  source: string;
  imageUrl?: string;
  publishedAt: string;
  relatedAssets?: string[];
  sentiment?: 'positive' | 'negative' | 'neutral';
}

class NewsService extends EventEmitter {
  private static instance: NewsService;
  private cachedNews: Map<string, NewsItem[]> = new Map();
  private lastFetchTime: Map<string, number> = new Map();
  private readonly CACHE_DURATION = 30 * 60 * 1000; // 30 minutes
  private readonly DEFAULT_ASSETS = ['BTC_USDT', 'ETH_USDT', 'SOL_USDT', 'BNB_USDT', 'XRP_USDT'];

  private constructor() {
    super();
  }

  static getInstance(): NewsService {
    if (!NewsService.instance) {
      NewsService.instance = new NewsService();
    }
    return NewsService.instance;
  }

  async getNewsForAsset(asset: string): Promise<NewsItem[]> {
    // Remove all underscores from asset symbol for consistent caching.
    const normalizedAsset = asset.replace(/_/g, '');
    
    // Check cache first.
    const cachedNews = this.cachedNews.get(normalizedAsset);
    const lastFetch = this.lastFetchTime.get(normalizedAsset) || 0;
    
    if (cachedNews && Date.now() - lastFetch < this.CACHE_DURATION) {
      return cachedNews;
    }
    
    try {
      const news = await this.fetchNewsForAsset(normalizedAsset);
      this.cachedNews.set(normalizedAsset, news);
      this.lastFetchTime.set(normalizedAsset, Date.now());
      return news;
    } catch (error) {
      console.warn(`Error fetching news for ${asset}:`, error);
      return cachedNews || [];
    }
  }

  async getNewsForAssets(assets: string[]): Promise<NewsItem[]> {
    if (!assets || assets.length === 0) {
      assets = this.DEFAULT_ASSETS;
    }
    
    const allNews: NewsItem[] = [];
    
    for (const asset of assets) {
      try {
        const news = await this.getNewsForAsset(asset);
        allNews.push(...news);
      } catch (error) {
        console.warn(`Error fetching news for ${asset}:`, error);
      }
    }
    
    // Remove duplicates and sort by published date (newest first)
    return this.deduplicateAndSortNews(allNews);
  }

  private deduplicateAndSortNews(news: NewsItem[]): NewsItem[] {
    // Use title as the unique key to remove duplicates.
    const uniqueNews = Array.from(
      new Map(news.map(item => [item.title, item])).values()
    );
    
    // Sort by published date (newest first)
    return uniqueNews.sort((a, b) => 
      new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
    );
  }

  private async fetchNewsForAsset(asset: string): Promise<NewsItem[]> {
    // Use CryptoCompare News API (free tier)
    try {
      const response = await fetch(
        `https://min-api.cryptocompare.com/data/v2/news/?categories=${asset}&excludeCategories=Sponsored`
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (!data.Data) {
        return [];
      }
      
      return data.Data.map((item: any) => ({
        id: item.id.toString(),
        title: item.title,
        description: item.body,
        url: item.url,
        source: item.source,
        imageUrl: item.imageurl,
        publishedAt: new Date(item.published_on * 1000).toISOString(),
        relatedAssets: item.categories.split('|'),
        sentiment: this.determineSentiment(item.title, item.body)
      }));
    } catch (error) {
      console.warn('Error fetching from CryptoCompare:', error);
      return this.generateMockNews(asset);
    }
  }

  private determineSentiment(title: string, body: string): 'positive' | 'negative' | 'neutral' {
    const text = (title + ' ' + body).toLowerCase();
    
    const positiveWords = ['bullish', 'surge', 'soar', 'gain', 'rally', 'rise', 'up', 'high', 'growth', 'positive'];
    const negativeWords = ['bearish', 'crash', 'plunge', 'drop', 'fall', 'down', 'low', 'loss', 'negative', 'concern'];
    
    let positiveScore = 0;
    let negativeScore = 0;
    
    positiveWords.forEach(word => {
      if (text.includes(word)) positiveScore++;
    });
    
    negativeWords.forEach(word => {
      if (text.includes(word)) negativeScore++;
    });
    
    if (positiveScore > negativeScore) return 'positive';
    if (negativeScore > positiveScore) return 'negative';
    return 'neutral';
  }

  private generateMockNews(asset: string): NewsItem[] {
    // Use the asset (assumed normalized) to generate mock news.
    const symbol = asset.replace('USDT', '');
    const currentDate = new Date();
    
    return [
      {
        id: `mock-${symbol}-1`,
        title: `${symbol} Shows Strong Momentum in Recent Trading Sessions`,
        description: `${symbol} has been showing strong momentum in recent trading sessions, with analysts pointing to increased institutional interest and positive market sentiment.`,
        url: 'https://example.com/news',
        source: 'Crypto Daily',
        imageUrl: `https://source.unsplash.com/random/300x200/?crypto,${symbol.toLowerCase()}`,
        publishedAt: new Date(currentDate.getTime() - 2 * 60 * 60 * 1000).toISOString(),
        relatedAssets: [symbol],
        sentiment: 'positive'
      },
      {
        id: `mock-${symbol}-2`,
        title: `Technical Analysis: ${symbol} Approaching Key Resistance Levels`,
        description: `Technical analysts are closely watching ${symbol} as it approaches key resistance levels. A breakthrough could signal a new bullish phase.`,
        url: 'https://example.com/news',
        source: 'CryptoAnalyst',
        imageUrl: `https://source.unsplash.com/random/300x200/?chart,${symbol.toLowerCase()}`,
        publishedAt: new Date(currentDate.getTime() - 8 * 60 * 60 * 1000).toISOString(),
        relatedAssets: [symbol],
        sentiment: 'neutral'
      },
      {
        id: `mock-${symbol}-3`,
        title: `${symbol} Development Update: New Features Coming Soon`,
        description: `The ${symbol} development team has announced new features that will be implemented in the coming weeks, potentially increasing utility and adoption.`,
        url: 'https://example.com/news',
        source: 'Blockchain Insider',
        imageUrl: `https://source.unsplash.com/random/300x200/?technology,${symbol.toLowerCase()}`,
        publishedAt: new Date(currentDate.getTime() - 24 * 60 * 60 * 1000).toISOString(),
        relatedAssets: [symbol],
        sentiment: 'positive'
      }
    ];
  }
}

export const newsService = NewsService.getInstance();
export type { NewsItem };
