import { logService } from './log-service';
import { supabase } from './supabase';
import { v4 as uuidv4 } from 'uuid';
import { AIService } from './ai-service';
import type { StrategyTemplate, RiskLevel } from './types';

class TemplateService {
  private static instance: TemplateService;
  private templates: Map<string, StrategyTemplate[]> = new Map();
  private lastGenerationTime: Map<string, number> = new Map();
  private initialized = false;
  private initializationPromise: Promise<void> | null = null;
  private readonly GENERATION_INTERVAL = 24 * 60 * 60 * 1000; // 24 hours
  private readonly DEEPSEEK_API_KEY = import.meta.env.VITE_DEEPSEEK_API_KEY;
  private readonly TEMPLATE_COUNT = 20; // Number of templates to generate daily

  private readonly TEMPLATE_TYPES = [
    {
      type: 'trend',
      description:
        'Trend following strategy using moving averages and momentum indicators',
      riskLevels: ['Medium', 'High'] as RiskLevel[],
      assets: ['BTC_USDT', 'ETH_USDT', 'SOL_USDT'],
    },
    {
      type: 'reversal',
      description:
        'Counter-trend strategy focusing on oversold/overbought conditions',
      riskLevels: ['High', 'Ultra High'] as RiskLevel[],
      assets: ['BTC_USDT', 'ETH_USDT'],
    },
    {
      type: 'breakout',
      description: 'Breakout trading strategy with volume confirmation',
      riskLevels: ['Medium', 'High'] as RiskLevel[],
      assets: ['BTC_USDT', 'ETH_USDT', 'SOL_USDT', 'BNB_USDT'],
    },
    {
      type: 'scalping',
      description: 'High-frequency scalping strategy with tight stops',
      riskLevels: ['High', 'Ultra High', 'Extreme'] as RiskLevel[],
      assets: ['SOL_USDT', 'BNB_USDT'],
    },
    {
      type: 'grid',
      description: 'Grid trading strategy for ranging markets',
      riskLevels: ['Low', 'Medium'] as RiskLevel[],
      assets: ['BTC_USDT', 'ETH_USDT'],
    },
    {
      type: 'momentum',
      description: 'Momentum-based strategy using multiple timeframes',
      riskLevels: ['Medium', 'High'] as RiskLevel[],
      assets: ['BTC_USDT', 'ETH_USDT', 'SOL_USDT'],
    },
  ];

  private readonly INDICATORS = {
    RSI: { period: 14 },
    MACD: { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
    BollingerBands: { period: 20, stdDev: 2 },
    EMA: { period: 20 },
    SMA: { period: 50 },
    ATR: { period: 14 },
    Stochastic: { period: 14, signalPeriod: 3 },
  };

  private constructor() {
    this.startPeriodicCheck();
  }

  static getInstance(): TemplateService {
    if (!TemplateService.instance) {
      TemplateService.instance = new TemplateService();
    }
    return TemplateService.instance;
  }

  private startPeriodicCheck() {
    setInterval(() => {
      this.checkForTemplateUpdates();
    }, 60 * 60 * 1000); // Check every hour
  }

  private async checkForTemplateUpdates() {
    try {
      const userIds = Array.from(this.lastGenerationTime.keys());
      for (const userId of userIds) {
        const lastGen = this.lastGenerationTime.get(userId) || 0;
        const now = Date.now();
        if (now - lastGen >= this.GENERATION_INTERVAL) {
          await this.generateTemplatesForUser(userId);
        }
      }
    } catch (error) {
      logService.log(
        'error',
        'Error checking for template updates',
        error,
        'TemplateService'
      );
    }
  }

  private async generateTemplatesForUser(userId: string): Promise<void> {
    try {
      logService.log(
        'info',
        `Generating templates for user ${userId}`,
        null,
        'TemplateService'
      );

      const templates: StrategyTemplate[] = [];
      const templatesPerType = Math.ceil(
        this.TEMPLATE_COUNT / this.TEMPLATE_TYPES.length
      );

      for (const templateType of this.TEMPLATE_TYPES) {
        for (let i = 0; i < templatesPerType; i++) {
          try {
            const riskLevel =
              templateType.riskLevels[
                Math.floor(Math.random() * templateType.riskLevels.length)
              ];

            // Build the strategy prompt
            const prompt = this.buildStrategyPrompt(templateType, riskLevel);

            // Generate strategy configuration using DeepSeek
            const config = await this.generateWithDeepSeek(
              prompt,
              riskLevel,
              templateType.assets
            );

            const template: StrategyTemplate = {
              id: uuidv4(),
              title:
                config.strategy_name ||
                `${
                  templateType.type.charAt(0).toUpperCase() +
                  templateType.type.slice(1)
                } Strategy ${i + 1}`,
              description:
                config.strategy_rationale || templateType.description,
              risk_level: riskLevel,
              metrics: {
                winRate: Number((65 + Math.random() * 20).toFixed(1)),
                avgReturn: Number((15 + Math.random() * 20).toFixed(1)),
              },
              config,
              user_id: userId,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            };

            templates.push(template);
          } catch (error) {
            logService.log(
              'error',
              `Failed to generate template for type ${templateType.type}`,
              error,
              'TemplateService'
            );
          }
        }
      }

      // Update cache with new templates
      this.templates.set(userId, templates);
      this.lastGenerationTime.set(userId, Date.now());

      // Save templates to database
      await this.saveTemplates(userId, templates);

      logService.log(
        'info',
        `Generated ${templates.length} templates for user ${userId}`,
        null,
        'TemplateService'
      );
    } catch (error) {
      logService.log(
        'error',
        `Failed to generate templates for user ${userId}`,
        error,
        'TemplateService'
      );
      throw error;
    }
  }

  private buildStrategyPrompt(
    templateType: (typeof this.TEMPLATE_TYPES)[0],
    riskLevel: RiskLevel
  ): string {
    const basePrompt = `Create a ${riskLevel.toLowerCase()} risk ${
      templateType.type
    } trading strategy.

Strategy Requirements:
1. Type: ${templateType.type}
2. Risk Level: ${riskLevel}
3. Description: ${templateType.description}
4. Assets: ${templateType.assets.join(', ')}

The strategy should include:
1. Clear entry and exit conditions using technical indicators
2. Risk management parameters appropriate for ${riskLevel} risk level
3. Position sizing and leverage limits
4. Specific indicator configurations with exact parameters
5. Market type selection (spot/futures) based on risk level
6. Detailed rationale for the strategy

Use common technical indicators like:
- RSI (Relative Strength Index)
- MACD (Moving Average Convergence Divergence)
- Bollinger Bands
- Moving Averages (SMA, EMA)
- Volume indicators
- ATR (Average True Range)
- Stochastic Oscillator

Ensure all parameters are specific and numeric.`;

    return basePrompt;
  }

  private async generateWithDeepSeek(
    prompt: string,
    riskLevel: RiskLevel,
    assets: string[]
  ): Promise<any> {
    if (!this.DEEPSEEK_API_KEY) {
      throw new Error('DeepSeek API key not configured');
    }

    try {
      const response = await fetch(
        'https://api.deepseek.com/v1/chat/completions',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${this.DEEPSEEK_API_KEY}`,
          },
          body: JSON.stringify({
            model: 'deepseek-chat',
            messages: [
              {
                role: 'user',
                content: `${prompt}

Return ONLY a JSON object with this EXACT structure:
{
  "strategy_name": string,
  "strategy_rationale": string,
  "market_type": "spot" | "futures",
  "assets": ${JSON.stringify(assets)},
  "trade_parameters": {
    "leverage": number,
    "position_size": number (0-1),
    "confidence_factor": number (0-1)
  },
  "conditions": {
    "entry": [
      {
        "indicator": string,
        "operator": ">" | "<" | ">=" | "<=" | "==" | "crosses_above" | "crosses_below",
        "value": number,
        "timeframe": string
      }
    ],
    "exit": [
      {
        "indicator": string,
        "operator": string,
        "value": number,
        "timeframe": string
      }
    ]
  },
  "risk_management": {
    "stop_loss": number,
    "take_profit": number,
    "trailing_stop_loss": number,
    "max_drawdown": number
  },
  "indicators": [
    {
      "name": string,
      "parameters": object,
      "weight": number
    }
  ]
}`,
              },
            ],
            temperature: 0.7,
            max_tokens: 1000,
          }),
        }
      );

      if (!response.ok) {
        throw new Error(`DeepSeek API error: ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;

      if (!content) {
        throw new Error('Empty response from DeepSeek');
      }

      // Extract JSON from response
      const jsonStart = content.indexOf('{');
      const jsonEnd = content.lastIndexOf('}');

      if (jsonStart === -1 || jsonEnd === -1) {
        throw new Error('No valid JSON found in response');
      }

      const jsonContent = content.substring(jsonStart, jsonEnd + 1);
      const config = JSON.parse(jsonContent);

      // Validate and normalize the configuration
      return this.normalizeStrategyConfig(config, riskLevel);
    } catch (error) {
      logService.log(
        'error',
        'Failed to generate strategy with DeepSeek',
        error,
        'TemplateService'
      );
      throw error;
    }
  }

  private normalizeStrategyConfig(config: any, riskLevel: RiskLevel): any {
    // Normalize risk parameters based on risk level
    const riskMultiplier =
      {
        'Ultra Low': 0.5,
        Low: 0.75,
        Medium: 1,
        High: 1.5,
        'Ultra High': 2,
        Extreme: 2.5,
        'God Mode': 3,
      }[riskLevel] || 1;

    // Determine market type based on risk level
    const marketType = ['High', 'Ultra High', 'Extreme', 'God Mode'].includes(
      riskLevel
    )
      ? 'futures'
      : 'spot';

    return {
      ...config,
      market_type: marketType,
      trade_parameters: {
        ...config.trade_parameters,
        leverage: Math.min(
          config.trade_parameters?.leverage || 1,
          marketType === 'futures' ? 5 : 1
        ),
        position_size: Math.min(
          config.trade_parameters?.position_size || 0.1,
          riskLevel === 'High' ? 0.15 : 0.1
        ),
        confidence_factor: Math.min(
          config.trade_parameters?.confidence_factor || 0.7,
          0.9
        ),
      },
      risk_management: {
        ...config.risk_management,
        stop_loss: Math.min(
          config.risk_management?.stop_loss || 2,
          5 * riskMultiplier
        ),
        take_profit: Math.min(
          config.risk_management?.take_profit || 6,
          15 * riskMultiplier
        ),
        trailing_stop_loss: Math.min(
          config.risk_management?.trailing_stop_loss || 1,
          3 * riskMultiplier
        ),
        max_drawdown: Math.min(
          config.risk_management?.max_drawdown || 15,
          30 * riskMultiplier
        ),
      },
    };
  }

  private async saveTemplates(
    userId: string,
    templates: StrategyTemplate[]
  ): Promise<void> {
    try {
      // Delete existing templates for this user
      await supabase.from('strategy_templates').delete().eq('user_id', userId);

      // Insert new templates
      const { error } = await supabase
        .from('strategy_templates')
        .insert(templates);

      if (error) throw error;

      logService.log(
        'info',
        `Saved ${templates.length} templates for user ${userId}`,
        null,
        'TemplateService'
      );
    } catch (error) {
      logService.log(
        'error',
        `Failed to save templates for user ${userId}`,
        error,
        'TemplateService'
      );
      throw error;
    }
  }

  async getTemplatesForUser(userId: string): Promise<StrategyTemplate[]> {
    if (!this.initialized) {
      await this.initialize();
    }

    try {
      // First try to get templates from the database
      const { data: dbTemplates, error } = await supabase
        .from('strategy_templates')
        .select('*')
        .eq('user_id', userId);

      if (error) throw error;

      // If no templates exist, generate new ones
      if (!dbTemplates || dbTemplates.length === 0) {
        await this.generateTemplatesForUser(userId);
        const userTemplates = this.templates.get(userId);
        return userTemplates || [];
      }

      // Update cache with database templates
      this.templates.set(userId, dbTemplates);
      this.lastGenerationTime.set(
        userId,
        new Date(dbTemplates[0].created_at).getTime()
      );

      return dbTemplates;
    } catch (error) {
      logService.log(
        'error',
        `Failed to get templates for user ${userId}`,
        error,
        'TemplateService'
      );

      // Return cached templates if available
      const cachedTemplates = this.templates.get(userId);
      if (cachedTemplates) {
        return cachedTemplates;
      }

      // Generate new templates as fallback
      await this.generateTemplatesForUser(userId);
      return this.templates.get(userId) || [];
    }
  }

  async initialize(): Promise<void> {
    if (this.initialized) return;
    if (this.initializationPromise) return this.initializationPromise;

    this.initializationPromise = (async () => {
      try {
        const { data: savedTemplates } = await supabase
          .from('strategy_templates')
          .select('*');

        if (savedTemplates) {
          savedTemplates.forEach((template) => {
            const userTemplates = this.templates.get(template.user_id) || [];
            userTemplates.push(template);
            this.templates.set(template.user_id, userTemplates);
            this.lastGenerationTime.set(
              template.user_id,
              new Date(template.created_at).getTime()
            );
          });
        }

        this.initialized = true;
        logService.log(
          'info',
          'Template service initialized successfully',
          null,
          'TemplateService'
        );
      } catch (error) {
        logService.log(
          'error',
          'Failed to initialize template service',
          error,
          'TemplateService'
        );
        throw error;
      } finally {
        this.initializationPromise = null;
      }
    })();

    return this.initializationPromise;
  }

  async getTemplates(): Promise<StrategyTemplate[]> {
    if (!this.initialized) {
      await this.initialize();
    }
    return Array.from(this.templates.values()).flat();
  }

  async getTemplateById(id: string): Promise<StrategyTemplate | null> {
    if (!this.initialized) {
      await this.initialize();
    }

    try {
      const { data: template, error } = await supabase
        .from('strategy_templates')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return template;
    } catch (error) {
      logService.log(
        'error',
        `Failed to get template ${id}`,
        error,
        'TemplateService'
      );
      return null;
    }
  }

  cleanup() {
    this.templates.clear();
    this.lastGenerationTime.clear();
    this.initialized = false;
  }
}

export const templateService = TemplateService.getInstance();
