import { EventEmitter } from './event-emitter';
import { tradeGenerator } from './trade-generator';
import { tradeManager } from './trade-manager';
import { tradeService } from './trade-service';
import { marketMonitor } from './market-monitor';
import { analyticsService } from './analytics-service';
import { exchangeService } from './exchange-service';
import { supabase } from './supabase';
import { logService } from './log-service';
import type { Strategy } from './supabase-types';
import type { MarketData, StrategyBudget } from './types';

class MarketService extends EventEmitter {
  private static instance: MarketService;
  private strategies: Map<string, Strategy> = new Map();
  private monitoredAssets: Set<string> = new Set();
  private isInitialized: boolean = false;
  private initializationPromise: Promise<void> | null = null;
  private initializationTimeout: number = 30000; // 30 second timeout

  private constructor() {
    super();
    this.setupEventListeners();
  }

  static getInstance(): MarketService {
    if (!MarketService.instance) {
      MarketService.instance = new MarketService();
    }
    return MarketService.instance;
  }

  private setupEventListeners() {
    tradeGenerator.on('tradeOpportunity', (data) => {
      this.emit('tradeOpportunity', data);
    });

    tradeManager.on('tradeExecuted', (data) => {
      this.emit('tradeExecuted', data);
      this.emit('strategyUpdate', { strategyId: data.trade.strategy_id });
    });

    marketMonitor.on('marketUpdate', (data) => {
      this.emit('marketUpdate', data);
    });
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;
    if (this.initializationPromise) return this.initializationPromise;

    this.initializationPromise = new Promise(async (resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Market service initialization timed out'));
      }, this.initializationTimeout);

      try {
        logService.log('info', 'Initializing market service', null, 'MarketService');

        // Initialize exchange service first
        await exchangeService.ensureInitialized();

        // Initialize required services in parallel
        await Promise.all([
          marketMonitor.initialize(),
          analyticsService.initialize(),
          tradeManager.initialize(),
          tradeGenerator.initialize()
        ]);

        this.isInitialized = true;
        clearTimeout(timeout);
        logService.log('info', 'Market service initialized successfully', null, 'MarketService');
        resolve();
      } catch (error) {
        clearTimeout(timeout);
        this.isInitialized = false;
        logService.log('error', 'Failed to initialize market service', error, 'MarketService');
        
        // Initialize in demo mode on error
        try {
          await exchangeService.initializeExchange({
            name: 'bitmart',
            apiKey: 'demo',
            secret: 'demo',
            memo: 'demo',
            testnet: true,
            useUSDX: false
          });
          
          await Promise.all([
            marketMonitor.initialize(),
            analyticsService.initialize(),
            tradeManager.initialize(),
            tradeGenerator.initialize()
          ]);
          
          this.isInitialized = true;
          resolve();
        } catch (fallbackError) {
          logService.log('error', 'Failed to initialize in demo mode', fallbackError, 'MarketService');
          reject(fallbackError);
        }
      } finally {
        this.initializationPromise = null;
      }
    });

    return this.initializationPromise;
  }

  async addAsset(symbol: string): Promise<void> {
    try {
      if (!this.isInitialized) {
        await this.initialize();
      }

      logService.log('info', `Adding asset to monitor: ${symbol}`, null, 'MarketService');

      this.monitoredAssets.add(symbol);
      await marketMonitor.addAsset(symbol);

      logService.log('info', `Successfully added asset: ${symbol}`, null, 'MarketService');
    } catch (error) {
      logService.log('error', `Failed to add asset: ${symbol}`, error, 'MarketService');
      throw error;
    }
  }

  async removeAsset(symbol: string): Promise<void> {
    try {
      logService.log('info', `Removing asset from monitor: ${symbol}`, null, 'MarketService');

      this.monitoredAssets.delete(symbol);
      marketMonitor.removeAsset(symbol);

      logService.log('info', `Successfully removed asset: ${symbol}`, null, 'MarketService');
    } catch (error) {
      logService.log('error', `Failed to remove asset: ${symbol}`, error, 'MarketService');
      throw error;
    }
  }

  async startStrategyMonitoring(strategy: Strategy): Promise<void> {
    try {
      if (!this.isInitialized) {
        await this.initialize();
      }

      logService.log('info', `Starting monitoring for strategy: ${strategy.id}`, null, 'MarketService');

      // Ensure strategy is not already being monitored
      if (this.strategies.has(strategy.id)) {
        await this.stopStrategyMonitoring(strategy.id);
      }

      // Validate strategy configuration
      if (!strategy.strategy_config?.assets || strategy.strategy_config.assets.length === 0) {
        throw new Error('Strategy has no configured trading pairs');
      }

      // Store strategy
      this.strategies.set(strategy.id, strategy);

      // Add all strategy assets to monitoring first
      for (const asset of strategy.strategy_config.assets) {
        await this.addAsset(asset);
      }

      // Initialize services after assets are monitored
      await Promise.all([
        tradeGenerator.addStrategy(strategy),
        tradeManager.initializeStrategy(strategy),
        analyticsService.trackStrategy(strategy)
      ]);

      logService.log('info', `Successfully started monitoring for strategy: ${strategy.id}`, null, 'MarketService');
      this.emit('strategyUpdate', { strategyId: strategy.id, status: 'active' });
    } catch (error) {
      logService.log('error', `Failed to start monitoring for strategy: ${strategy.id}`, error, 'MarketService');
      // Clean up if initialization fails
      this.strategies.delete(strategy.id);
      throw error;
    }
  }

  async stopStrategyMonitoring(strategyId: string): Promise<void> {
    try {
      logService.log('info', `Stopping monitoring for strategy: ${strategyId}`, null, 'MarketService');

      const strategy = this.strategies.get(strategyId);
      if (!strategy) {
        throw new Error(`Strategy ${strategyId} not found`);
      }

      // Remove strategy assets from monitoring if no other strategy uses them
      if (strategy.strategy_config?.assets) {
        for (const asset of strategy.strategy_config.assets) {
          const isUsedByOtherStrategy = Array.from(this.strategies.values())
            .some(s => s.id !== strategyId && s.strategy_config?.assets?.includes(asset));

          if (!isUsedByOtherStrategy) {
            await this.removeAsset(asset);
          }
        }
      }

      // Remove from trade generator
      tradeGenerator.removeStrategy(strategyId);

      // Close all open trades
      const openTrades = tradeManager.getActiveTradesForStrategy(strategyId);
      for (const trade of openTrades) {
        await tradeManager.closeTrade(trade.id);
      }

      // Clear budget
      await tradeService.setBudget(strategyId, null);

      // Remove from monitored strategies
      this.strategies.delete(strategyId);

      logService.log('info', `Successfully stopped monitoring for strategy: ${strategyId}`, null, 'MarketService');
      this.emit('strategyUpdate', { strategyId, status: 'inactive' });
    } catch (error) {
      logService.log('error', `Failed to stop monitoring for strategy: ${strategyId}`, error, 'MarketService');
      throw error;
    }
  }

  async deleteStrategy(strategyId: string): Promise<void> {
    try {
      logService.log('info', `Deleting strategy: ${strategyId}`, null, 'MarketService');

      // Stop monitoring first to close trades and clean up
      if (this.strategies.has(strategyId)) {
        await this.stopStrategyMonitoring(strategyId);
      }

      // Delete all trades for this strategy
      const { error: tradesError } = await supabase
        .from('strategy_trades')
        .delete()
        .eq('strategy_id', strategyId);

      if (tradesError) {
        logService.log('warn', `Error deleting trades for strategy ${strategyId}`, tradesError, 'MarketService');
      }

      // Delete strategy budget history
      const { error: budgetHistoryError } = await supabase
        .from('budget_history')
        .delete()
        .eq('strategy_id', strategyId);

      if (budgetHistoryError) {
        logService.log('warn', `Error deleting budget history for strategy ${strategyId}`, budgetHistoryError, 'MarketService');
      }

      // Delete strategy budget
      const { error: budgetError } = await supabase
        .from('strategy_budgets')
        .delete()
        .eq('strategy_id', strategyId);

      if (budgetError) {
        logService.log('warn', `Error deleting budget for strategy ${strategyId}`, budgetError, 'MarketService');
      }

      // Finally delete the strategy itself
      const { error: strategyError } = await supabase
        .from('strategies')
        .delete()
        .eq('id', strategyId);

      if (strategyError) {
        // Handle 406 errors silently for non-existent strategies
        if (strategyError.code === 'PGRST116') {
          this.strategies.delete(strategyId);
          return;
        }
        throw strategyError;
      }

      logService.log('info', `Successfully deleted strategy: ${strategyId}`, null, 'MarketService');
    } catch (error: any) {
      // Handle 406 errors silently for non-existent strategies
      if (error.code === 'PGRST116') {
        this.strategies.delete(strategyId);
        return;
      }
      logService.log('error', `Failed to delete strategy: ${strategyId}`, error, 'MarketService');
      throw error;
    }
  }

  processMarketData(data: MarketData): void {
    this.emit('marketData', data);
  }

  isStrategyActive(strategyId: string): boolean {
    return this.strategies.has(strategyId);
  }

  getActiveStrategies(): Strategy[] {
    return Array.from(this.strategies.values());
  }

  getMonitoredAssets(): string[] {
    return Array.from(this.monitoredAssets);
  }

  getStrategyPerformance(strategyId: string): any {
    const strategy = this.strategies.get(strategyId);
    if (!strategy) return null;

    // Get analytics data
    const analytics = analyticsService.getLatestAnalytics(strategyId);
    if (!analytics) return null;

    return {
      totalPnl: analytics.metrics.pnl,
      totalTrades: analytics.trades.total,
      winRate: analytics.metrics.winRate,
      maxDrawdown: analytics.metrics.maxDrawdown,
      duration: '30d',
      equityCurve: analytics.metrics.equityCurve || []
    };
  }

  cleanup(): void {
    for (const strategyId of this.strategies.keys()) {
      this.stopStrategyMonitoring(strategyId).catch(error => {
        logService.log('error', `Failed to clean up strategy: ${strategyId}`, error, 'MarketService');
      });
    }

    this.strategies.clear();
    this.monitoredAssets.clear();
    this.isInitialized = false;

    // Clean up all services
    tradeGenerator.cleanup();
    tradeManager.cleanup();
    marketMonitor.cleanup();
    analyticsService.cleanup();
    tradeService.clearAllBudgets();
  }
}

export const marketService = MarketService.getInstance();